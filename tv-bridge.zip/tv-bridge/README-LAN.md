# LAN-hubben – flera enheter på ett eget nätverk (version 1.1.0)

Hubben är `bridge.js` (samma program som TV-bridgen). Den gör två saker:
1. **Serverar hela sajten** över http på port 8787 (fungerar helt utan internet).
2. **Synkar** matchläge mellan alla enheter som öppnat sidorna från hubben (Klocka, På isen, OVR, Speaker, Jumbotron, Domarskärm m.fl.).
TV-utgången (RossTalk/OSC/HTTP/datafeed) fungerar precis som förut.

**Bara lokalt nätverk** – ingen molntjänst, ingen internetsynk. Utan hubb (t.ex. github.io-sajten) fungerar allt som innan, på en enhet/webbläsare.

## 1. Starta hubben på datorn
### Mac (Apple Silicon, ingen installation)
1. Packa upp `tv-bridge.zip`. Packa upp `hub-mac-arm64.zip` och lägg filen `matchklocka-hub-mac-arm64` **i samma mapp** som `bridge.js` / `Starta-Hubben.command`.
2. Första gången: **högerklicka `Starta-Hubben.command` → Öppna → Öppna** (Gatekeeper varnar för program som inte är signerade av Apple). Startskriptet tar själv bort karantänflaggan från programfilen. Alternativ i Terminal:
   `xattr -dr com.apple.quarantine ~/Hämtade-filer/tv-bridge` (peka på mappen du packade upp).
3. macOS frågar **"Vill du att programmet ska tillåta inkommande anslutningar?" → Tillåt.** (Svarar du Neka: Systeminställningar → Nätverk → Brandvägg → Alternativ → tillåt `matchklocka-hub-mac-arm64`. Står brandväggen på "blockera alla inkommande" måste det läget av.)
4. Låt Terminal-fönstret vara öppet under matchen. Datorn hålls vaken så länge hubben kör (stängt lock = sömn = hubben dör; koppla in nätadapter och låt locket vara öppet).
Har du Node.js installerat går `node bridge.js` lika bra (`Starta-Hubben.command` väljer själv).

### Windows
Installera Node.js LTS, dubbelklicka `start.bat`. (Tillåt Windows-brandväggen för "privata nätverk" när den frågar.)

### Linux / Raspberry Pi
`./start.sh` (Node 16+). Autostart på Pi: skapa en systemd-tjänst som kör `/sökväg/start.sh`, eller lägg raden i `crontab -e`: `@reboot /sökväg/start.sh`.

Flaggor: `--port 8787` · `--fresh` (starta med tomt läge, annars laddas sista läget från `lan-state.json`) · `--nolan` (bara TV-bridge, ingen synk) · `--serve mapp`.

## 2. Nätverket
- Egen router/switch, alla enheter (iPads, datorer) på **samma** nät. Ingen internet behövs.
- **Ge hubb-datorn fast IP** (DHCP-reservation i routern på datorns MAC-adress, eller manuell IP i macOS/Windows). Då är adresserna samma varje match.
- Hubben skriver ut alla adresser när den startar, t.ex. `http://192.168.1.50:8787/` och `http://<datornamn>.local:8787/` (Bonjour – iPad/iPhone/Mac/Windows 10+ klarar `.local`, vissa Android inte; använd IP där).
- Spara adressen som bokmärke / "Lägg till på hemskärmen" på varje enhet.

## 3. Vilken enhet öppnar vad
Byt `<hubb>` mot IP-adressen (eller `datornamn.local`). **Öppna alltid från hubben, inte från github.io** (https-sidor får inte nå ws:// på lokala nätet).

| Enhet | Adress |
|---|---|
| **Klocka** (en enda enhet) | `http://<hubb>:8787/matchklocka/kontroll.html` |
| På isen (hemma-platta / borta-platta) | `http://<hubb>:8787/matchklocka/paisen.html?lag=hemma` / `?lag=borta` |
| OVR Rapport | `http://<hubb>:8787/matchklocka/ovr.html` |
| Speaker | `http://<hubb>:8787/speaker.html` |
| Jumbotron | `http://<hubb>:8787/matchklocka/jumbotron.html` |
| Domarskärm | `http://<hubb>:8787/matchklocka/domare.html` |
| Omklädningsrum | `http://<hubb>:8787/matchklocka/omkladningsrum.html` |
| Skott & puckinnehav | `http://<hubb>:8787/matchklocka/skott.html` |

Hubben kan köras på samma dator som Klocka (då är Klocka-fliken också bara en webbläsare mot `http://localhost:8787/…`). TV-utgång: i Klocka, bridge-adress `ws://localhost:8787`.

## 4. Indikatorn
Operatörssidor (Klocka, På isen, OVR, Speaker, Skott) har en liten ruta nere till vänster. **Aldrig** på Jumbotron, Domarskärm, omklädningsrum och TV/NDI-sidor (publika skärmar).
- Grön **LAN ansluten · N enheter** – allt synkas.
- Gul **LAN ansluter… / återansluter…** – försöker (några sekunder vid hubbomstart).
- Röd blinkande **LAN OFFLINE – ändringar delas inte** efter 8 s utan hubb. Sidan fungerar lokalt vidare och skickar allt som hänt när hubben är tillbaka.
**Puls / frånkopplad:** hubben skickar en puls varje sekund (med Klockas fulla läge, så skärmarna synkas om hela tiden – även när klockan står still). Omklädningsrum, Domarskärm och Jumbotron visar en liten röd markering **● frånkopplad** nere till höger om de inte hört något på 4,5 s. Klockan fortsätter räkna lokalt; markeringen försvinner och tiden synkas om så fort pulsen kommer tillbaka. Visas aldrig på TV/NDI-sidor eller Jumbotron med `?ndi`/`?bg`.
Utan hubb (github.io, `file://`) syns ingen ruta. Tvinga av/på: lägg `?lan=off` / `?lan=<ip>:8787` / `?lan=auto` efter adressen en gång (sparas i webbläsaren).

## 5. Vad synkas
- **Klockans läge** (klocka, period, mål, utvisningar, laguppställningar m.m.). **Klocka är enda skrivare** – andra enheter kan inte skriva över det (hubben avvisar). Kör bara **en** Klocka per match.
- **På isen** (spelare på isen, målvakt in/ut → TOM KASSE på OVR, byten, protokoll), **Speaker-protokoll och -överstyrningar**, laguppställningar, publik, **Skott & puckinnehav**.
- Konflikter: senaste ändring vinner (hel nyckel åt gången). Två På isen-plattor låsta med `?lag=hemma`/`?lag=borta` fungerar bra samtidigt; flera plattor på samma lag kan skriva över varandra.
- **Klockskev**: hubben är tidsreferens. Varje enhet mäter sin klockskillnad mot hubben och räknar speltiden därefter, så att en iPad som går 40 s fel ändå visar rätt tid. Tid på dygnet (Time of day) följer hubb-datorns klocka – ställ den rätt.
- Synkas **inte**: TV-utgångens inställningar (hör till den Klocka som kör bridgen) och påminnelseflaggor per enhet (t.ex. "Fullt lag"-popup).
- Hubben sparar läget i `lan-state.json` (överlever omstart). Ny match = ladda match i Klocka/Nollställ som vanligt; vill du tömma hubben helt: starta med `--fresh`.

## 6. Utan internet (offline)
Alla sidor, typsnitt och bilder serveras av hubben – ingen CDN. Fungerar offline: allt ovan, "Hämta automatisk match" (använder `aktuell.js` från senaste publicering), manuell inmatning, TV-utgång mot lokala IP-adresser.
**Fungerar inte offline** (felmeddelande, inget kraschar, fyll i manuellt): "Hämta match" med matchnummer från swehockey, laguppställning från swehockey, Speakers automatiska händelsehämtning från swehockey. Förbered därför matchen medan du har internet (publicera med rätt match så ligger laguppställningen i `aktuell.js` och Speaker-filerna).

## 7. Felsökning
- **Enhet når inte hubben:** fungerar `http://<hubb>:8787/status` i enhetens webbläsare? Nej → samma nät? Brandvägg (Mac: Tillåt inkommande; Windows: privat nätverk)? **Gästnät/"AP isolation"/"client isolation"** på routern stoppar enhet-till-enhet-trafik – stäng av, eller använd inte gästnätet. VPN avstängt.
- **Ruta är gul/röd men hubben kör:** öppnades sidan från github.io eller fel IP? Öppna från hubbens adress. Kontrollera att IP:n inte ändrats (fast IP/DHCP-reservation).
- **Port upptagen:** `--port 8788` (och använd samma port i adressen).
- **`.local` fungerar inte:** använd IP-adressen.
- **Status:** `http://<hubb>:8787/admin` (se avsnitt 9) visar enheter, status och logg. `http://<hubb>:8787/lan/status` (JSON) visar anslutna enheter och nycklar – numera också bara från privata adresser.
- **Mac: "kan inte öppnas"/"skadad":** `xattr -dr com.apple.quarantine <mappen>` och kör `codesign --force --sign - matchklocka-hub-mac-arm64`.
- **Ladda om en sida** är alltid ofarligt – den hämtar fullt läge från hubben direkt.

## 8. Bygga om Mac-filen (utvecklare)
`bridge/build-mac.sh` (bun krävs) → `bridge/dist/matchklocka-hub-mac-arm64`; `publish.sh` packar den som `hub-mac-arm64.zip`.

## 9. Adminsida och logg (`/admin`)
Öppna `http://<hubb>:8787/admin` (t.ex. på datorn: `http://127.0.0.1:8787/admin`). Hubben skriver också adressen i terminalen vid start. Sidan uppdateras live (1 gång/s) och visar:
- **Klocka:** ansluten eller inte, hur länge sedan hubben hörde från den, samt match, ställning, period/klocktid och om klockan går.
- **Anslutna enheter:** sida, roll, IP-adress, enhet (webbläsare), ansluten sedan, tid sedan senaste meddelande och klockskev. Färg: **grön** < 8 s, **gul** 8–20 s, **röd** > 20 s sedan senaste meddelande (enheterna pingar var 4:e sekund, så i normalfallet är alla gröna). Enheter kopplas inte bort automatiskt när de blir tysta – de visas bara som gula/röda tills anslutningen faller.
- **Hubbens adresser** (alla nätverkskort + port) och **länkar till alla skärmar** (välj adress i rullistan).
- **Logg:** senaste händelserna live, nyast överst. Filter: alla / **bara matchhändelser** / bara avvikelser / anslutningar / synk / klocka. Textsök, **Äldst först** (kronologisk läsning), dagväljare för äldre dagar, **CSV-export** (matchhändelser eller alla händelser, semikolonseparerad, öppnas direkt i Excel) och **Skriv ut** (utskriftsvänlig tabell). Klick på en rad visar detaljer. Sidan visar också loggens sparningstid, tak och aktuell storlek.

### Åtkomst
- Adminsidan, `/admin/data`, `/admin/export` och `/lan/status` svarar **bara** på privata adresser: 127.0.0.0/8, 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16 och 100.64.0.0/10 (Tailscale/CGNAT) samt 169.254.0.0/16 och IPv6 lokal/ULA (::1, fe80::, fc00::/7). Övriga får 403. Proxy-huvudet `X-Forwarded-For` kontrolleras också, så en tunnel/proxy som vidarebefordrar publika klienter nekas. Inga CORS-huvuden skickas, så en webbsida på internet kan inte läsa adminsidan via en besökares webbläsare.
- **PIN:** adminsidan kräver dessutom PIN-kod om en sådan är satt (se avsnitt 10). Utan PIN är åtkomsten bara nätverksbaserad – **publikens/läktarens wifi bör då vara ett eget, separat nätverk** (eget SSID/VLAN utan väg till hubbens nät).
- Vid körning bakom en omvänd proxy/tunnel på samma dator ser hubben alla anrop som 127.0.0.1 om proxyn inte sätter `X-Forwarded-For` – exponera då inte hubbens port via tunnel.

### Loggfiler
- Mapp: `logs/` bredvid `bridge.js` / Mac-filen (ändra med `LOG_DIR=…` eller `"logDir"` i `config.json`). En fil per dag (svensk tid): `logs/YYYY-MM-DD.jsonl`, en JSON-rad per händelse. Hubben läser in dagens senaste rader vid start och har ~1000 händelser i minnet för livevyn.
- Fält: `ts` (ms sedan 1970), `dag`, `tid` (HH:MM:SS, Europe/Stockholm), `typ`, `niv` (`info`/`avvikelse`), `m` (1 = matchhändelse), `match` (hemma – borta), `per`, `kt` (period + klocktid som på klockan, t.ex. `P2 12:34`), `lag`, `nr`, `straff`, `text` (svenska) och `d` (detaljer).
- **Städning:** filer äldre än `LOG_DAYS` (standard **180** dagar; även `"logDays"` i `config.json`) raderas automatiskt vid hubbstart och därefter varje dygn. Dessutom tak för hela mappen, `LOG_MAX_MB` (standard **500** MB, `"logMaxMB"`): äldsta dagfilerna raderas först (dagens fil raderas aldrig). Endast `YYYY-MM-DD.jsonl` rörs. Inställningen och aktuell storlek visas längst ned i loggkortet.
- Storlek: ca 230 byte per händelse, uppskattningsvis 250–400 händelser en normal matchdag ≈ **60–100 kB** (högst ett par hundra kB med mycket återanslutningar). 180 dagar blir i praktiken några MB, så 500 MB-taket nås aldrig i normal drift.

### Vad som loggas
| Typ | Innehåll |
|---|---|
| `anslutning` | enhet ansluten/frånkopplad (sida, IP, enhet, hur länge den var uppkopplad), Klocka ansluten/frånkopplad (avvikelse om klockan gick när den försvann) |
| `synk` | tappad synk (ingen signal på 12 s) och återkontakt per enhet; enhet som hade annat läge än Klocka efter puls och omsynkades |
| `klocka` | klockan startad/stoppad (med klocktid), manuell klockjustering |
| `period` | periodbyte (P1 → PAUS → P2 …) |
| `mål` | mål (lag, ställning, period + klocktid), borttaget mål |
| `utvisning` | utvisning (lag, nummer, straff/minuter, samtidig), utvisning slut, borttagen/ändrad |
| `timeout`, `powerbreak` | start och slut/avbruten |
| `nollställning` | ny match/nollställning, "Nollställ allt", hubbens lagrade läge rensat |
| `avvikelse` | se nedan |
| `system` | hubb startad (version, loggkonfiguration) |

Matchhändelser (mål, utvisning, period, klockstart/stopp, timeout, powerbreak, nollställning) har alltid **period och klocktid som visad på klockan** (`kt`, t.ex. `P2 12:34`), lag, spelarnummer och straff i egna kolumner – avsett för att stämma av mot sekretariatets rapporter. Klockans tid räknas ut i hubben (även för uppräknande klocka) – ingen ändring i Klocka-skärmen. Skottstatistik loggas inte (perioden byter plats på skotten och skulle ge falska händelser).

### Avvikelser
Egen typ/nivå `avvikelse`, gulmarkerad i loggen med filter "Bara avvikelser" och en räknare överst på sidan (antal senaste timmen). Hubben jämför Klockas läge före/efter varje ändring. Fångas:
- två enheter har Klocka-rollen (och att båda skriver);
- en klient hade ett annat läge än Klocka efter en puls (omsynkades);
- klockan hoppar bakåt eller mer än 1,5 s åt något håll utan att ha gått (manuell justering; bakåt eller över 1 min = avvikelse);
- mål eller utvisning borttaget/ändrat/flyttat efteråt, eller raderat ur historiken;
- ställningen ändras utan matchande målhändelse, eller **minskar**;
- klockan går under pågående timeout/powerbreak, går förbi 0:00, går i perioden SLUT, eller visar längre tid än periodens längd;
- periodbyte bakåt (t.ex. P3 → P1, SLUT → P2);
- en klient som inte är Klocka försöker ändra klockans läge (avvisas av hubben);
- Klocka-skrivning med äldre tidsstämpel än hubbens (konflikt);
- felaktig PIN (adminsidan eller operatörssidor) och skrivförsök från en skrivskyddad anslutning utan PIN;
- okänt sidnamn ansluter; stort klockskev (> 30 s mellan enhet och hubb);
- upprepade återanslutningar (5+ på 5 min för samma enhet och sida);
- nollställning av en match som pågår (ej slutförd);
- tappad synk (enhet tyst > 12 s) och Klocka som försvinner medan klockan går.
Varje avvikelse loggas en gång när den uppstår (inte en gång per sekund).

### Begränsningar / ej klart i v1
- Matcher skiljs bara åt via fältet `match` och nollställningar i loggen – ingen separat fil per match.
- Konflikt vid äldre skrivning (`stale`) kontrolleras bara för Klockas läge.
- Enheter som tappar kontakt utan att stänga anslutningen (strömsparläge) visas som gul/röd tills hubben märker att socketen dött.
- Klientsidan skickar nu sidans identitet (`lag`) och sin klockskev i `hello`/ping samt ett `resync`-meddelande när den avviker från Klocka – inga ändringar i beteendet på skärmarna.
- Mac-filen (`bun --compile`) måste byggas om (`publish.sh` gör det automatiskt) för att få med `lanadmin.js`/`lanadmin-page.js`.

## 10. PIN-kod (operatörssidor och admin)
PIN är **valfri**. Är ingen PIN satt fungerar allt precis som förut.

### Ställ in PIN
- I `config.json` bredvid `bridge.js` / Mac-filen: `{"adminPin": "1234"}` (se `config.sample.jsonc`), **eller** miljövariabeln `ADMIN_PIN=1234`. Miljövariabeln vinner. Tom/saknas = ingen PIN. Starta om hubben efter ändring.
- PIN:en ligger **bara** i den lokala `config.json` (och ev. env). Den finns inte i källkoden eller i `site/`, och `config.json` följer **inte** med `publish.sh` (bara `config.sample.jsonc` paketeras) – lägg den därför för hand bredvid Mac-filen på hubbdatorn. Filen `session.secret` (skapas automatiskt bredvid, chmod 600) används för att signera inloggningscookies och ska inte delas/publiceras. Hubbens startrad visar om PIN krävs ("PIN krävs"/"INGEN PIN satt"), aldrig själva koden.
- Byt PIN = redigera `config.json` + starta om; då blir **alla** inloggade enheter ogiltiga. Radera `session.secret` för att också slumpa om nyckeln.

### Vad som skyddas
| Skyddas (PIN) | Öppet utan PIN |
|---|---|
| **Operatörssidor:** `matchklocka/kontroll.html` (Klocka), `matchklocka/index.html` (meny), `ovr.html`, `paisen.html` (På isen), `skott.html` (Skott/innehav), `speaker.html` | **Displaysidor:** `domare.html`, `omkladningsrum.html`, `jumbotron.html`, `tv.html`, `ndi-mal.html`, `ndi-scorebug.html`, `ndi-utvisning.html` samt skript, bilder och övriga filer |
| **Adminsidan** `/admin`, `/admin/data`, `/admin/export` (dessutom bara privata adresser) | `/lan/snapshot`, `/state`, `/status`, `/config` (skrivskyddade läsningar) samt **Klocka→TV-bridgen** (WebSocket på `/` och `/event`) – oförändrat öppen |
| **WebSocket `/lan` – skrivning:** Klocka-rollen och alla `set`-meddelanden kräver operatörscookie. Anslutningar utan cookie är **skrivskyddade**: de får läge och uppdateringar som vanligt, men Klocka-roll nekas och skrivningar ignoreras (loggas som avvikelse). | Skrivskyddade displayklienter ansluter utan PIN |

`speaker-fristaende.html`, `kommentator.html` och rotens `index.html` är inte operatörssidor i hubben och är öppna (de skriver inget till hubben utan Speaker/Klocka). `publik_*`-nycklarna i synken skrivs av Speaker (operatör), inte av någon öppen sida.

### Inloggning och cookies
- Operatörssida utan giltig cookie → omdirigeras till `/login` (svensk PIN-ruta) och därefter tillbaka till sidan. Cookien `mk_op` är **HttpOnly, SameSite=Strict, giltig 30 dagar per enhet**.
- Adminsidan har egen PIN-ruta och cookie `admin_sess` (**12 timmar**, Path `/admin`). Operatörscookien öppnar inte admin. Admin har kvar kravet på privat adress.
- Cookies är signerade (inte lagrade i hubben) → **inloggade enheter fortsätter fungera efter hubbomstart**.
- Felaktig PIN: högst **5 försök/minut per IP** (gäller operatör och admin gemensamt), därefter 429 i 1 minut även med rätt kod. Varje fel loggas som `avvikelse`; lyckad inloggning loggas som `system`. PIN skrivs aldrig i loggen.
- **Spärrade IP-adresser:** adminsidan visar ett kort "PIN-spärrar" (bara när någon är spärrad) med IP och återstående tid, en knapp **Lås upp** per IP och **Lås upp alla**. Åtgärden är en POST till `/admin/unlock` som kräver admin-inloggning; varje upplåsning loggas som `system`-händelse. Admin delar samma spärr: är adminens egen IP spärrad kommer man inte in på adminsidan för att låsa upp, utan spärren släpper av sig själv efter högst 1 minut (eller så låser en annan admin-inloggad enhet upp den).
- **Klocka→TV-bridgen** (WebSocket på `/` och `/event`) har ingen PIN och är öppen som förut.
