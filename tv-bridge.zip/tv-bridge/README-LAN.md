# LAN-hubben – flera enheter på ett eget nätverk (version 1.1.0)

Hubben är `bridge.js` (samma program som TV-bridgen). Den gör två saker:
1. **Serverar hela sajten** över http på port 8787 (fungerar helt utan internet).
2. **Synkar** matchläge mellan alla enheter som öppnat sidorna från hubben (Klocka, På isen, OVR, Speaker, Jumbotron, Domarskärm m.fl.).
TV-utgången (RossTalk/OSC/HTTP/datafeed) fungerar precis som förut.

**Bara lokalt nätverk** – ingen molntjänst, ingen internetsynk. Utan hubb (t.ex. github.io-sajten) fungerar allt som innan, på en enhet/webbläsare.

## 1. Starta hubben på datorn
### Mac (Apple Silicon, ingen installation)
1. Packa upp `tv-bridge.zip`. Packa upp `hub-mac-arm64.zip` och lägg filen `matchklocka-hub-mac-arm64` **i samma mapp** som `bridge.js` / `Starta-Hubben.command`.
2. Första gången: **högerklicka `Starta-Hubben.command` → Öppna → Öppna** (Gatekeeper varnar för program som inte är signerade av Apple). Startskriptet tar själv bort karantänflaggan från programfilen. Alternativ i Terminal:
   `xattr -dr com.apple.quarantine ~/Hämtade-filer/tv-bridge` (peka på mappen du packade upp).
3. macOS frågar **"Vill du att programmet ska tillåta inkommande anslutningar?" → Tillåt.** (Svarar du Neka: Systeminställningar → Nätverk → Brandvägg → Alternativ → tillåt `matchklocka-hub-mac-arm64`. Står brandväggen på "blockera alla inkommande" måste det läget av.)
4. Låt Terminal-fönstret vara öppet under matchen. Datorn hålls vaken så länge hubben kör (stängt lock = sömn = hubben dör; koppla in nätadapter och låt locket vara öppet).
Har du Node.js installerat går `node bridge.js` lika bra (`Starta-Hubben.command` väljer själv).

### Windows
Installera Node.js LTS, dubbelklicka `start.bat`. (Tillåt Windows-brandväggen för "privata nätverk" när den frågar.)

### Linux / Raspberry Pi
`./start.sh` (Node 16+). Autostart på Pi: skapa en systemd-tjänst som kör `/sökväg/start.sh`, eller lägg raden i `crontab -e`: `@reboot /sökväg/start.sh`.

Flaggor: `--port 8787` · `--fresh` (starta med tomt läge, annars laddas sista läget från `lan-state.json`) · `--nolan` (bara TV-bridge, ingen synk) · `--serve mapp`.

## 2. Nätverket
- Egen router/switch, alla enheter (iPads, datorer) på **samma** nät. Ingen internet behövs.
- **Ge hubb-datorn fast IP** (DHCP-reservation i routern på datorns MAC-adress, eller manuell IP i macOS/Windows). Då är adresserna samma varje match.
- Hubben skriver ut alla adresser när den startar, t.ex. `http://192.168.1.50:8787/` och `http://<datornamn>.local:8787/` (Bonjour – iPad/iPhone/Mac/Windows 10+ klarar `.local`, vissa Android inte; använd IP där).
- Spara adressen som bokmärke / "Lägg till på hemskärmen" på varje enhet.

## 3. Vilken enhet öppnar vad
Byt `<hubb>` mot IP-adressen (eller `datornamn.local`). **Öppna alltid från hubben, inte från github.io** (https-sidor får inte nå ws:// på lokala nätet).

| Enhet | Adress |
|---|---|
| **Klocka** (en enda enhet) | `http://<hubb>:8787/matchklocka/kontroll.html` |
| På isen (hemma-platta / borta-platta) | `http://<hubb>:8787/matchklocka/paisen.html?lag=hemma` / `?lag=borta` |
| OVR Rapport | `http://<hubb>:8787/matchklocka/ovr.html` |
| Speaker / Speaker U18 | `http://<hubb>:8787/speaker.html` / `speaker-u18.html` |
| Jumbotron | `http://<hubb>:8787/matchklocka/jumbotron.html` |
| Domarskärm | `http://<hubb>:8787/matchklocka/domare.html` |
| Omklädningsrum | `http://<hubb>:8787/matchklocka/omkladningsrum.html` |
| Skott & puckinnehav | `http://<hubb>:8787/matchklocka/skott.html` |

Hubben kan köras på samma dator som Klocka (då är Klocka-fliken också bara en webbläsare mot `http://localhost:8787/…`). TV-utgång: i Klocka, bridge-adress `ws://localhost:8787`.

## 4. Indikatorn
Operatörssidor (Klocka, På isen, OVR, Speaker, Skott) har en liten ruta nere till vänster. **Aldrig** på Jumbotron, Domarskärm, omklädningsrum och TV/NDI-sidor (publika skärmar).
- Grön **LAN ansluten · N enheter** – allt synkas.
- Gul **LAN ansluter… / återansluter…** – försöker (några sekunder vid hubbomstart).
- Röd blinkande **LAN OFFLINE – ändringar delas inte** efter 8 s utan hubb. Sidan fungerar lokalt vidare och skickar allt som hänt när hubben är tillbaka.
Utan hubb (github.io, `file://`) syns ingen ruta. Tvinga av/på: lägg `?lan=off` / `?lan=<ip>:8787` / `?lan=auto` efter adressen en gång (sparas i webbläsaren).

## 5. Vad synkas
- **Klockans läge** (klocka, period, mål, utvisningar, laguppställningar m.m.). **Klocka är enda skrivare** – andra enheter kan inte skriva över det (hubben avvisar). Kör bara **en** Klocka per match.
- **På isen** (spelare på isen, målvakt in/ut → TOM KASSE på OVR, byten, protokoll), **Speaker-protokoll och -överstyrningar**, laguppställningar, publik, **Skott & puckinnehav**.
- Konflikter: senaste ändring vinner (hel nyckel åt gången). Två På isen-plattor låsta med `?lag=hemma`/`?lag=borta` fungerar bra samtidigt; flera plattor på samma lag kan skriva över varandra.
- **Klockskev**: hubben är tidsreferens. Varje enhet mäter sin klockskillnad mot hubben och räknar speltiden därefter, så att en iPad som går 40 s fel ändå visar rätt tid. Tid på dygnet (Time of day) följer hubb-datorns klocka – ställ den rätt.
- Synkas **inte**: TV-utgångens inställningar (hör till den Klocka som kör bridgen) och påminnelseflaggor per enhet (t.ex. "Fullt lag"-popup).
- Hubben sparar läget i `lan-state.json` (överlever omstart). Ny match = ladda match i Klocka/Nollställ som vanligt; vill du tömma hubben helt: starta med `--fresh`.

## 6. Utan internet (offline)
Alla sidor, typsnitt och bilder serveras av hubben – ingen CDN. Fungerar offline: allt ovan, "Hämta automatisk match" (använder `aktuell.js` från senaste publicering), manuell inmatning, TV-utgång mot lokala IP-adresser.
**Fungerar inte offline** (felmeddelande, inget kraschar, fyll i manuellt): "Hämta match" med matchnummer från swehockey, laguppställning från swehockey, Speakers automatiska händelsehämtning från swehockey. Förbered därför matchen medan du har internet (publicera med rätt match så ligger laguppställningen i `aktuell.js` och Speaker-filerna).

## 7. Felsökning
- **Enhet når inte hubben:** fungerar `http://<hubb>:8787/status` i enhetens webbläsare? Nej → samma nät? Brandvägg (Mac: Tillåt inkommande; Windows: privat nätverk)? **Gästnät/"AP isolation"/"client isolation"** på routern stoppar enhet-till-enhet-trafik – stäng av, eller använd inte gästnätet. VPN avstängt.
- **Ruta är gul/röd men hubben kör:** öppnades sidan från github.io eller fel IP? Öppna från hubbens adress. Kontrollera att IP:n inte ändrats (fast IP/DHCP-reservation).
- **Port upptagen:** `--port 8788` (och använd samma port i adressen).
- **`.local` fungerar inte:** använd IP-adressen.
- **Status:** `http://<hubb>:8787/lan/status` visar anslutna enheter och nycklar.
- **Mac: "kan inte öppnas"/"skadad":** `xattr -dr com.apple.quarantine <mappen>` och kör `codesign --force --sign - matchklocka-hub-mac-arm64`.
- **Ladda om en sida** är alltid ofarligt – den hämtar fullt läge från hubben direkt.

## 8. Bygga om Mac-filen (utvecklare)
`bridge/build-mac.sh` (bun krävs) → `bridge/dist/matchklocka-hub-mac-arm64`; `publish.sh` packar den som `hub-mac-arm64.zip`.
