# Matchklocka TV-bridge

Tar emot händelser från **Klocka** (matchklockans styrsida, `matchklocka/kontroll.html`) och skickar dem vidare som nätverkstriggers
(RossTalk, TCP/UDP-text, OSC, HTTP) till sändarens grafik. Ren Node.js (16+), inga beroenden, inga installationer.

```
Klocka (webbläsare) --WebSocket--> bridge.js --> RossTalk/TCP/UDP/OSC/HTTP --> grafik
```

## Starta
- Windows: dubbelklicka `start.bat` · macOS/Linux/Pi: `./start.sh` (startar om sig själv om processen dör)
- Alternativ: `node bridge.js [--port 8787] [--host 0.0.0.0] [--config fil.json] [--serve mapp] [--verbose]`
- Varje händelse och varje utskick loggas i konsolen med tid, mål och exakt sträng/OSC/HTTP.

## Ställ in (allt görs i Klocka)
Klocka → **TV-utgång**: slå på, bridge-adress `ws://localhost:8787`, lägg in utgångar och koppla händelser till strängar. Mallar finns
för RossTalk GPI, CasparCG, Companion, Singular och OSC; konfigen kan exporteras/importeras som JSON.
Konfigen sparas i Klocka och **skickas till bridgen vid anslutning och vid varje ändring**; bridgen tillämpar den direkt och sparar
senast mottagna som `config.received.json` (reserv om Klocka inte är uppkopplad vid omstart).
Startordning vid bridge-start: `config.received.json` > `config.json` (valfri, se `config.sample.jsonc`; `"ignoreReceived": true` ger
`config.json` företräde). En tom konfig i Klocka skriver aldrig över bridgens konfig vid anslutning.

## Händelser
`clockStart` `clockStop` `periodStart` `periodEnd` (klockan nådde 0:00 – tuta) `goalHome` `goalAway` `goalRemoved` `penaltyAdded`
`penaltyExpired` `timeout` `powerbreak` `gameReset`. Händelserna härleds ur matchläget, så även automatiska (periodslut,
utvisning ute) kommer med. `periodStart` skickas en gång per period, vid första start från full periodtid. Händelser köas inte:
är bridgen nere vid tillfället skickas de aldrig i efterhand.

## Utgångstyper
| typ | fält | skickas |
|---|---|---|
| `rosstalk` / `tcp` | host, port, eol (`crlf` std, `lf`, `cr`, `none`) | text + radslut, en ihållande anslutning per host:port (återansluter) |
| `udp` | host, port, eol (std `none`) | text i ett datagram |
| `osc` | host, port | OSC 1.0 över UDP. Utskick: `msg` = adress, `args` = argument; heltal→`i`, decimal→`f`, `"text"`/övrigt→`s`, `true/false` |
| `http` | url (bas), method GET/POST/PUT/PATCH, headers (`Namn: v; Namn2: v`) | `msg` = sökväg/URL efter basen, `body` = valfri body (JSON om den börjar med `{`/`[`) |

Utskick per händelse är en lista: en händelse kan ge flera utskick till samma eller olika utgångar.

## Variabler (i msg/args/body)
`{clock}` visad klocka · `{clockms}` · `{period}` P1/P2/P3/OT/PAUS/SLUT · `{periodname}` · `{home}` `{away}` **mål** hemma/borta ·
`{score}` 2-1 · `{homename}` `{awayname}` lagnamn · `{homeshort}` `{awayshort}` · `{team}` `{teamshort}` `{side}` (home/away) `{teamgoals}`
laget i händelsen · `{nr}` `{pen}` (2, 2+2, 5, 10 …) `{min}` `{player}` vid utvisning · `{strength}` (t.ex. "4 mot 5") · `{homepens}` `{awaypens}`
aktiva utvisningar · `{gid}` matchnr · `{time}` klartid · `{event}`.
Filter: `{x|json}` (escapar för JSON-sträng) `{x|url}` `{x|upper}` `{x|lower}` `{x|xml}`. I text: `\r` `\n` `\t`.

## Datafeed (valfri)
Klocka → TV-utgång → Datafeed: på/av, UDP eller TCP, host:port, 1–30 Hz. En JSON-rad per paket:
`{"t":ms,"stale":false,"running":true,"clock":"12:34","clockMs":754000,"period":"P2","home":{"name","short","score","shots","pens":[{"nr","kind","leftMs","left","active"}]},"away":{…},"strength":"4 mot 5","timeout":null,"powerbreak":null,"gid","mid"}`.
Klocka skickar status vid ändring + var sekund; bridgen räknar klockan/utvisningar mellan uppdateringarna och sätter `stale:true` efter 3,5 s
utan data. Samma JSON finns som `GET /state`.

## HTTP-gränssnitt (utan Klocka, för test)
`GET|POST /event/<namn>` (POST-body `{"vars":{"home":3,…}}`), `GET /state`, `GET /status`, `GET /config`. CORS är öppet.
Exempel: `curl -X POST localhost:8787/event/goalHome -d '{"vars":{"home":3,"away":1}}'`

## Webbläsare, https och ws:// (läs detta)
Klocka på GitHub Pages är https. Webbläsaren tillåter då bara `ws://localhost` – **inte `ws://192.168.x.x`** (mixed content).
- **Rekommenderat:** kör bridgen på samma dator som Klocka → `ws://localhost:8787`. Chrome 142+ kan fråga om "lokal nätverksåtkomst" första gången – tillåt.
  Safari kan blockera ws://localhost från https; använd då Chrome/Edge eller läget nedan.
- **Pi/egen dator:** bridgen kan själv servera sajten över http (`site/` bredvid `bridge.js` – finns i zip-filen – eller `--serve mapp`).
  Öppna `http://<bridgens-ip>:8787/matchklocka/kontroll.html` på Klocka-datorn, ställ bridge-adressen till `ws://<bridgens-ip>:8787`.
  OBS: lagring är per adress/origin – alla skärmar (Jumbotron, TV, Domare …) måste öppnas från samma adress för att dela matchläge.
- Bridge-adressen sparas per webbläsare. Klocka fungerar helt normalt om bridgen saknas; den återansluter tyst.

## Säkerhet
Bridgen har ingen inloggning – kör den bara på ett stängt produktionsnät. Kan nås av alla på porten; bind till `127.0.0.1` (`--host 127.0.0.1`) om bara lokal Klocka ska använda den.

## Exempel
- **RossTalk:** typ `rosstalk`, port 7788, `GPI 5` (ändra `eol` till `none`/`lf` om motparten kräver det).
- **CasparCG:** typ `tcp`, port 5250: `CG 1-10 UPDATE 1 "{\"home\":{home}}"` följt av `CG 1-10 INVOKE 1 "goalHome"`.
- **Companion:** typ `http`, url `http://127.0.0.1:8000`, msg `/api/location/1/0/3/press` (sida/rad/kolumn).
- **Singular:** typ `http`, url `https://app.singular.live/apiv2/controlapps/<TOKEN>/control`, metod `PATCH`, body `[{"subCompositionName":"Scoreboard","payload":{"Home":"{home}"}}]`.
- **OSC:** adress `/mal/hemma`, args `{home} {away} "{homeshort}"`.

Fler exempel med kommentarer: `config.sample.jsonc`.
