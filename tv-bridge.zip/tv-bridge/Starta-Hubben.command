#!/bin/bash
# Dubbelklicka för att starta LAN-hubben på Mac (ingen installation behövs).
# Första gången: högerklicka → Öppna → Öppna (Gatekeeper). Se README-LAN.md, avsnitt "Starta på Macen".
# Hubben serverar hela sajten på port 8787 till alla enheter på samma nätverk och öppnar en startsida med adresser + QR-koder.
cd "$(dirname "$0")" || exit 1
BIN="./matchklocka-hub-mac-arm64"
# Ta bort "hämtad från internet"-flaggan så att den medföljande programfilen får köras
xattr -dr com.apple.quarantine . 2>/dev/null
SITE_OK=0; { [ -d site/matchklocka ] || [ -d ../site/matchklocka ]; } && SITE_OK=1
if [ "$SITE_OK" = 0 ]; then
  echo "Mappen site/ saknas bredvid det här skriptet – hubben har inga sidor att visa."
  echo "Packa upp hela zip-filen (Matchklocka-Hubb-Mac.zip, eller tv-bridge.zip) och starta härifrån."; echo; read -n1 -p "Tryck en tangent..."; exit 1
fi
if [ -f "$BIN" ] && [ "$(uname -m)" = "arm64" ]; then
  chmod +x "$BIN"
  # Behåll Ad-hoc-signaturen hel; signera om vid behov (Apple Silicon kräver signatur)
  codesign --verify "$BIN" >/dev/null 2>&1 || codesign --force --sign - "$BIN" >/dev/null 2>&1
  RUN=("$BIN")
elif command -v node >/dev/null 2>&1; then
  RUN=(node bridge.js)
else
  echo "Hittar varken matchklocka-hub-mac-arm64 (Apple Silicon) eller Node.js."; echo "Läs README-LAN.md."; read -n1 -p "Tryck en tangent..."; exit 1
fi
# NDI Jumbotron-hjälpare (valfri): starta om appen/binären finns. Hubben startar ändå om den saknas.
start_ndi_helper() {
  if curl -fsS --max-time 1 "http://127.0.0.1:8791/health" >/dev/null 2>&1; then
    echo "NDI Jumbotron-hjälpare kör redan på port 8791."
    return 0
  fi
  local CANDS=(
    "./Matchklocka NDI Jumbotron.app"
    "./ndi-sender/Matchklocka NDI Jumbotron.app"
    "../ndi-sender/Matchklocka NDI Jumbotron.app"
    "./Matchklocka NDI Jumbotron"
    "../ndi-sender/Matchklocka NDI Jumbotron"
  )
  local c
  for c in "${CANDS[@]}"; do
    if [ -d "$c" ]; then
      xattr -dr com.apple.quarantine "$c" 2>/dev/null
      open "$c" >/dev/null 2>&1 && echo "Startade NDI Jumbotron-hjälpare: $c" && return 0
    fi
    if [ -x "$c" ] && [ ! -d "$c" ]; then
      xattr -dr com.apple.quarantine "$c" 2>/dev/null
      nohup "$c" >/dev/null 2>&1 &
      echo "Startade NDI Jumbotron-binär: $c"
      return 0
    fi
  done
  echo "NDI Jumbotron-hjälpare saknas (valfritt) – hoppar över. Bygg med ndi-sender/Bygg.command och lägg .app bredvid hubben eller i ndi-sender/."
  return 0
}
start_ndi_helper

echo "Startar LAN-hubben. Låt det här fönstret vara öppet under matchen (stäng = hubben stannar)."
echo "Datorn hålls vaken medan hubben kör (caffeinate). Första gången: tryck Tillåt när macOS frågar om inkommande anslutningar."
echo "En startsida med adresser och QR-koder öppnas i webbläsaren om en stund."
echo
FIRST=1
while true; do
  T0=$(date +%s)
  # Webbläsaren öppnas bara första gången (inte vid automatisk omstart)
  HUB_OPEN=$FIRST caffeinate -dis "${RUN[@]}" "$@"
  RC=$?
  FIRST=0
  # Stoppade den direkt (t.ex. port upptagen)? Då hjälper det inte att starta om i en loop.
  if [ $RC -ne 0 ] && [ $(( $(date +%s) - T0 )) -lt 5 ]; then
    echo; echo "Hubben kunde inte starta (se meddelandet ovan). Är den redan igång i ett annat fönster? Stäng det först."
    read -n1 -p "Tryck en tangent för att stänga..."; exit 1
  fi
  echo; echo "Hubben stoppade. Startar om om 3 sekunder (stäng fönstret / Ctrl+C för att avsluta)..."; sleep 3
done
