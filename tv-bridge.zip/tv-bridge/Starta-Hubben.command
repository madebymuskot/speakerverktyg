#!/bin/bash
# Dubbelklicka för att starta LAN-hubben på Mac (ingen installation behövs).
# Första gången: högerklicka → Öppna → Öppna (Gatekeeper). Se README-LAN.md.
cd "$(dirname "$0")" || exit 1
BIN="./matchklocka-hub-mac-arm64"
# Ta bort "hämtad från internet"-flaggan så att den medföljande programfilen får köras
xattr -dr com.apple.quarantine . 2>/dev/null
if [ -f "$BIN" ] && [ "$(uname -m)" = "arm64" ]; then
  chmod +x "$BIN"
  # Behåll Ad-hoc-signaturen hel; signera om vid behov (Apple Silicon kräver signatur)
  codesign --verify "$BIN" >/dev/null 2>&1 || codesign --force --sign - "$BIN" >/dev/null 2>&1
  RUN=("$BIN")
elif command -v node >/dev/null 2>&1; then
  RUN=(node bridge.js)
else
  echo "Hittar varken matchklocka-hub-mac-arm64 (Apple Silicon) eller Node.js."; echo "Läs README-LAN.md."; read -n1 -p "Tryck en tangent..."; exit 1
fi
echo "Startar LAN-hubben. Låt det här fönstret vara öppet under matchen (stäng = hubben stannar)."
echo "Datorn hålls vaken medan hubben kör (caffeinate). Första gången: tryck Tillåt när macOS frågar om inkommande anslutningar."
echo
while true; do
  caffeinate -dis "${RUN[@]}" "$@"
  echo; echo "Hubben stoppade. Startar om om 3 sekunder (stäng fönstret / Ctrl+C för att avsluta)..."; sleep 3
done
