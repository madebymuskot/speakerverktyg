'use strict';
/* Hämtar dagens/nästa Piteå HC-hemmamatch i LF Arena (A + U18, inte U20) från Swehockey
   och bygger window.AKTUELL. Schemat visar /Game/Events/<id> först vid nedsläpp, så saknas id
   provas Game/LineUps/<id> nära kända id:n (samma metod som speaker.py). Schema-id används aldrig som gid. */
const https = require('https');
const http = require('http');
const fs = require('fs');
const {URL} = require('url');

const BASE = 'https://stats.swehockey.se';
const UA = 'Mozilla/5.0 (matchklocka-hub)';
const SERIES = [{id: 21043, lag: 'A'}, {id: 21300, lag: 'U18'}];
const VENUES = new Set(['isstadion lf arena', 'lf arena']);
const HOME = 'Piteå HC';
const PROBE_DAYS = 1, PROBE_PARALLEL = 20, PROBE_BEFORE = 40, PROBE_AFTER = 150;
const STILL_MS = 4 * 3600 * 1000;
const MSG_WAIT = 'Väntar på laglista';

const ws = s => String(s || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
const venue = x => VENUES.has(ws(x).toLowerCase());
const isHome = teams => ws(teams && teams[0]) === HOME;

function stockholmParts(d) {
  return Object.fromEntries(new Intl.DateTimeFormat('sv-SE', {
    timeZone: 'Europe/Stockholm', year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23'
  }).formatToParts(d).filter(p => p.type !== 'literal').map(p => [p.type, p.value]));
}
function stockholmDate(d) { const p = stockholmParts(d); return p.year + '-' + p.month + '-' + p.day; }
function stockholmEpoch(date, time) {
  let n = Date.parse(date + 'T' + time + ':00Z');
  const target = n;
  for (let i = 0; i < 3; i++) {
    const p = stockholmParts(new Date(n));
    const local = Date.parse(p.year + '-' + p.month + '-' + p.day + 'T' + p.hour + ':' + p.minute + ':' + p.second + 'Z');
    n += target - local;
  }
  return n;
}
function startMs(g) { return stockholmEpoch(g.date, g.time); }

function parseAsof(s) {
  if (!s) return new Date();
  const m = String(s).trim().match(/^(\d{4}-\d{2}-\d{2})(?:[T ](\d{1,2}:\d{2}))?/);
  if (m) return new Date(stockholmEpoch(m[1], m[2] || '12:00'));
  const d = new Date(s);
  return Number.isNaN(+d) ? new Date() : d;
}

function httpGet(url, redirects) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const lib = u.protocol === 'http:' ? http : https;
    const req = lib.get(u, {headers: {'User-Agent': UA}, timeout: 20000}, res => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && (redirects || 0) < 3) {
        res.resume();
        return httpGet(new URL(res.headers.location, u).href, (redirects || 0) + 1).then(resolve, reject);
      }
      if (res.statusCode !== 200) {
        const err = new Error('HTTP ' + res.statusCode);
        err.status = res.statusCode;
        res.resume();
        return reject(err);
      }
      res.setEncoding('utf8');
      let b = '';
      res.on('data', d => { b += d; if (b.length > 8e6) { res.destroy(); reject(new Error('för stort svar')); } });
      res.on('end', () => resolve(b));
    });
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
    req.on('error', reject);
  });
}
const getPath = p => httpGet(BASE + p);

function parseSchedule(html, lag) {
  const out = [];
  let date = '';
  const rows = html.split(/<tr\b/i).slice(1);
  for (const row of rows) {
    const tr = row.replace(/^[^>]*>/, '').split(/<\/tr>/i)[0];
    const tds = [...tr.matchAll(/<td\b[^>]*>([\s\S]*?)<\/td>/gi)].map(m => m[1]);
    if (tds.length < 4) continue;
    const txt = tds.map(td => ws(td.replace(/<[^>]+>/g, ' ')));
    const dm = txt[0].match(/\b(\d{4}-\d{2}-\d{2})\b/);
    if (dm) date = dm[1];
    const timeCell = txt.find(t => /^(?:\d{4}-\d{2}-\d{2} )?\d{1,2}:\d{2}$/.test(t));
    const game = txt.find(t => /.+ - .+/.test(t) && !/\d+ - \d+$/.test(t));
    if (!date || !timeCell || !game) continue;
    const teams = game.split(' - ').map(ws);
    if (teams.length < 2) continue;
    const ev = tr.match(/\/Game\/Events\/(\d+)/);
    const tip = tr.match(/lnkTooltip"[^>]*title="(\d+)"/i) || tr.match(/title="(\d+)"[^>]*lnkTooltip/i);
    const sid = tip ? tip[1] : null;
    const gid = ev ? ev[1] : null;
    if (gid && sid && gid === sid) continue;
    out.push({
      date, time: timeCell.slice(-5), teams, arena: txt[txt.length - 1], lag,
      scheduleId: sid, gid, result: txt.find(t => /^\d+ - \d+$/.test(t)) || '',
      cancelled: /cancelled|postponed|inställd|uppskjuten/i.test(txt.join(' '))
    });
  }
  return out;
}

function parseGamesByDate(html) {
  const out = [];
  let series = '';
  const rows = html.split(/<tr\b/i).slice(1);
  for (const row of rows) {
    const tr = row.replace(/^[^>]*>/, '').split(/<\/tr>/i)[0];
    const tds = [...tr.matchAll(/<td\b[^>]*>([\s\S]*?)<\/td>/gi)].map(m => m[1]);
    const sched = tr.match(/\/ScheduleAndResults\/Schedule\/(\d+)/);
    if (sched && tds.length <= 1) { series = ws(tr.replace(/<[^>]+>/g, ' ')); continue; }
    if (tds.length < 4) continue;
    const txt = tds.map(td => ws(td.replace(/<[^>]+>/g, ' ')));
    const ev = tr.match(/\/Game\/Events\/(\d+)/);
    const tip = tr.match(/lnkTooltip"[^>]*title="(\d+)"/i) || tr.match(/title="(\d+)"[^>]*lnkTooltip/i);
    const sid = tip ? tip[1] : null;
    const gid = ev ? ev[1] : null;
    if (gid && sid && gid === sid) continue;
    const lag = /\bU18\b/.test(series) ? 'U18' : /\b(U20|J20)\b/.test(series) ? 'U20' : 'A';
    if (lag !== 'A') continue;
    out.push({
      date: null, time: (txt[0].match(/\b(\d{1,2}:\d{2})\b/) || [null, ''])[1],
      teams: ws(txt[1]).split(' - ').map(ws), arena: txt[3] || txt[txt.length - 1], lag,
      scheduleId: sid, gid, result: '', cancelled: false, series
    });
  }
  return out;
}

function parseLineup(html) {
  const text = ws(html.replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<[^>]+>/g, ' '));
  const teams = [];
  let team = null, role = null;
  const rows = html.split(/<tr\b/i).slice(1);
  for (const row of rows) {
    const tr = row.replace(/^[^>]*>/, '').split(/<\/tr>/i)[0];
    if (/<table\b/i.test(tr)) continue;
    const t = ws(tr.replace(/<[^>]+>/g, ' '));
    const tm = t.match(/^(.+?) \((Red|Blue|White|Black|Yellow|Green|Orange|Grey|Gray|\w+)\)$/);
    const cells = (tr.match(/<t[hd]\b/gi) || []).length;
    const hasPlayer = /lineUpPlayer/i.test(tr);
    if (tm && cells <= 2 && !/Referee/.test(t) && !hasPlayer) {
      team = {name: ws(tm[1]), players: []};
      teams.push(team);
      role = null;
      continue;
    }
    if (!team) continue;
    const sm = tr.match(/<strong>([\s\S]*?)<\/strong>/i);
    if (sm && ws(sm[1].replace(/<[^>]+>/g, ''))) role = ws(sm[1].replace(/<[^>]+>/g, ''));
    const isD = [...tr.matchAll(/<td(\b[^>]*)>([\s\S]*?)<\/td>/gi)].some(m => !/colspan=/i.test(m[1] || '') && !/<strong/i.test(m[2] || ''));
    const re = /<div\b[^>]*class="[^"]*lineUpPlayer[^"]*"[^>]*>([\s\S]*?)<\/div>/gi;
    let d;
    while ((d = re.exec(tr))) {
      const mm = ws(d[1]).match(/^(\d+)\.\s*(.+?),\s*(.+)$/);
      if (!mm || team.players.some(p => p.no === mm[1])) continue;
      let pos = isD ? 'B' : 'F', ln = 0;
      if (role === 'Goalies') { pos = 'M'; ln = 0; }
      else { const n = (role || '').match(/\d/); ln = n ? +n[0] : 0; }
      team.players.push({no: mm[1], name: ws(mm[3] + ' ' + mm[2]), pos, ln});
    }
  }
  for (const t of teams) {
    const gk = t.players.filter(p => p.pos === 'M');
    const sk = t.players.filter(p => p.pos !== 'M' && p.ln);
    const ex = t.players.filter(p => p.pos !== 'M' && !p.ln);
    if (sk.length > 1 && sk[0].ln > sk[sk.length - 1].ln) { sk.reverse(); gk.reverse(); }
    t.players = gk.concat(sk, ex);
  }
  return {teams, text};
}

function lineupMatches(lu, g) {
  if (!lu || !lu.text) return false;
  const t = lu.text.toLowerCase();
  const h = ws(g.teams[0]).toLowerCase(), a = ws(g.teams[1]).toLowerCase();
  return t.includes(g.date) && t.includes(h + ' - ' + a);
}

function homeGames(games) {
  return games.filter(g => isHome(g.teams) && venue(g.arena) && !g.cancelled && g.time && g.time !== '00:00');
}

function pickGame(games, now) {
  const t = +now;
  const still = homeGames(games).filter(g => t <= startMs(g) + STILL_MS).sort((a, b) => startMs(a) - startMs(b));
  return still[0] || null;
}

function waitingObj(g, msg) {
  const teams = (g && g.teams && g.teams.length >= 2)
    ? g.teams.slice(0, 2).map(n => ({name: n, players: []}))
    : [];
  return {lag: (g && g.lag) || '', gid: null, date: (g && g.date) || '', time: (g && g.time) || '', teams, status: 'waiting', message: msg || MSG_WAIT};
}

function readyObj(g, teams) {
  return {lag: g.lag, gid: String(g.gid), date: g.date, time: g.time, teams, status: 'ready'};
}

function toScript(obj) { return 'window.AKTUELL=' + JSON.stringify(obj) + ';'; }

function loadCache(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) { return {}; }
}
function saveCache(file, cache) {
  try { fs.writeFileSync(file, JSON.stringify(cache, null, 1), 'utf8'); } catch (e) {}
}

async function mapPool(items, n, fn) {
  const ret = new Array(items.length);
  let i = 0;
  async function worker() {
    while (i < items.length) {
      const j = i++;
      try { ret[j] = await fn(items[j]); } catch (e) { ret[j] = null; }
    }
  }
  await Promise.all(Array.from({length: Math.min(n, items.length)}, worker));
  return ret;
}

async function probeMissingIds(games, opts) {
  const get = (opts && opts.get) || getPath;
  const now = (opts && opts.now) || new Date();
  const cacheFile = opts && opts.cacheFile;
  const cache = cacheFile ? loadCache(cacheFile) : ((opts && opts.cache) || {});
  const today = stockholmDate(now);
  const todayD = new Date(today + 'T00:00:00Z');
  // Bara Piteås LF Arena-hemmamatcher (övriga seriematcher ger bara kända id-intervall).
  const need = games.filter(g => {
    if (g.gid || !isHome(g.teams) || !venue(g.arena)) return false;
    const days = Math.abs((Date.parse(g.date + 'T00:00:00Z') - +todayD) / 86400000);
    return days <= PROBE_DAYS;
  });
  for (const g of need) {
    if (g.scheduleId && cache[g.scheduleId] && cache[g.scheduleId] !== g.scheduleId) {
      g.gid = String(cache[g.scheduleId]);
      g.idSource = 'lineups_probe';
    }
  }
  const still = need.filter(g => !g.gid);
  const known = [...new Set(games.map(g => g.gid).filter(id => id && /^\d+$/.test(id) && !games.some(x => x.scheduleId === id)))].map(Number).sort((a, b) => a - b);
  if (!still.length || !known.length) { if (cacheFile) saveCache(cacheFile, cache); return games; }
  const lo = known[0] - PROBE_BEFORE, hi = known[known.length - 1] + PROBE_AFTER;
  const knownSet = new Set(known.map(String));
  const cands = [];
  for (let i = lo; i <= hi; i++) if (!knownSet.has(String(i))) cands.push(i);
  await mapPool(cands, PROBE_PARALLEL, async i => {
    if (!still.some(g => !g.gid)) return null;
    let html;
    try { html = await get('/Game/LineUps/' + i); } catch (e) { return null; }
    const t = ws(html.replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<[^>]+>/g, ' ')).toLowerCase();
    for (const g of still) {
      if (g.gid) continue;
      const h = ws(g.teams[0]).toLowerCase(), a = ws(g.teams[1]).toLowerCase();
      if (t.includes(g.date) && t.includes(h + ' - ' + a)) {
        g.gid = String(i);
        g.idSource = 'lineups_probe';
        if (g.scheduleId) cache[g.scheduleId] = String(i);
        return i;
      }
    }
    return null;
  });
  if (cacheFile) saveCache(cacheFile, cache);
  return games;
}

function mergeGames(lists) {
  const out = [], seen = new Set();
  for (const list of lists) {
    for (const g of list) {
      const key = [g.date, g.time, (g.teams || []).join('|'), g.lag].join('#');
      const prev = out.find(x => [x.date, x.time, x.teams.join('|'), x.lag].join('#') === key);
      if (prev) { if (!prev.gid && g.gid) prev.gid = g.gid; if (!prev.scheduleId && g.scheduleId) prev.scheduleId = g.scheduleId; continue; }
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(g);
    }
  }
  return out;
}

async function collectGames(opts) {
  const get = (opts && opts.get) || getPath;
  const now = (opts && opts.now) || new Date();
  const asof = stockholmDate(now);
  const lists = [];
  const knownForProbe = [];
  for (const s of SERIES) {
    const html = await get('/ScheduleAndResults/Schedule/' + s.id);
    const all = parseSchedule(html, s.lag);
    knownForProbe.push(...all);
    lists.push(all);
  }
  try {
    const html = await get('/GamesByDate/' + asof);
    const gd = parseGamesByDate(html).filter(g => g.lag === 'A');
    for (const g of gd) if (!g.date) g.date = asof;
    lists.push(gd);
  } catch (e) {}
  const games = mergeGames(lists);
  // Samma objekt som i games (plus ev. övriga seriematcher) så att hittade id:n hamnar på rätt rad.
  const probeList = mergeGames([knownForProbe, games]);
  await probeMissingIds(probeList, opts);
  return games;
}

async function buildAktuell(opts) {
  const get = (opts && opts.get) || getPath;
  const now = (opts && opts.now) || new Date();
  const games = await collectGames(opts);
  const g = pickGame(games, now);
  if (!g) return {lag: '', gid: null, date: '', time: '', teams: [], status: 'none', message: 'Ingen kommande hemmamatch hittades'};
  if (!g.gid) return waitingObj(g);
  let html;
  try { html = await get('/Game/LineUps/' + g.gid); }
  catch (e) { return waitingObj(g); }
  const lu = parseLineup(html);
  if (!lineupMatches(lu, g) || lu.teams.length < 2 || lu.teams.some(t => !t.players.length)) return waitingObj(g);
  if (lu.teams.some((t, i) => ws(t.name) !== ws(g.teams[i]))) return waitingObj(g);
  return readyObj(g, lu.teams);
}

function ttlMs(obj, now) {
  if (obj && obj.date && obj.date === stockholmDate(now)) return 60 * 1000;
  return 15 * 60 * 1000;
}

function create(opts) {
  const dir = (opts && opts.dir) || __dirname;
  const log = (opts && opts.log) || (() => {});
  const cacheFile = (opts && opts.cacheFile) || (dir + require('path').sep + 'gameid_cache.json');
  const getter = (opts && opts.get) || getPath;
  let cache = {at: 0, asof: '', obj: null};
  let busy = null;
  let timer = null;

  async function refresh(now) {
    now = now || new Date();
    const obj = await buildAktuell({get: getter, now, cacheFile, log});
    cache = {at: Date.now(), asof: String(+now), obj};
    const info = obj.status + (obj.gid ? ' gid=' + obj.gid : '') + (obj.date ? ' ' + obj.date : '');
    log('aktuell.js: ' + info);
    return obj;
  }

  function needRefresh(now, asofKey, force) {
    if (force || !cache.obj || cache.asof !== asofKey) return true;
    return (Date.now() - cache.at) > ttlMs(cache.obj, now);
  }

  async function getObj(u, force) {
    const q = (u && u.searchParams) || new URLSearchParams();
    const now = parseAsof(q.get('asof'));
    const asofKey = q.get('asof') || 'now';
    if (!needRefresh(now, asofKey, force || q.get('refresh') === '1')) return cache.obj;
    if (busy && busy.key === asofKey) return busy.p;
    const p = refresh(now).finally(() => { if (busy && busy.p === p) busy = null; });
    busy = {key: asofKey, p};
    return p;
  }

  async function script(u) {
    try { return toScript(await getObj(u)); }
    catch (e) {
      log('aktuell.js fel: ' + ((e && e.message) || e));
      return toScript({lag: '', gid: null, date: '', time: '', teams: [], status: 'error', message: 'Kunde inte hämta matchen från Swehockey'});
    }
  }

  function start() {
    const tick = () => {
      getObj(null).catch(e => log('aktuell.js uppdatering: ' + ((e && e.message) || e)));
    };
    tick();
    timer = setInterval(tick, 60 * 1000);
    if (timer.unref) timer.unref();
    return timer;
  }

  function stop() { if (timer) clearInterval(timer); timer = null; }

  return {refresh, getObj, script, start, stop, cache: () => cache};
}

module.exports = {
  SERIES, VENUES, MSG_WAIT, venue, isHome, ws, stockholmDate, stockholmEpoch, parseAsof,
  parseSchedule, parseGamesByDate, parseLineup, lineupMatches, homeGames, pickGame,
  waitingObj, readyObj, toScript, probeMissingIds, collectGames, buildAktuell, create, httpGet, getPath
};
