#!/usr/bin/env node
/* Matchklocka TV-bridge – tar emot händelser från Klocka (WebSocket/HTTP) och skickar dem vidare som
   RossTalk/TCP/UDP/OSC/HTTP enligt konfig. Inga beroenden (bara Node 16+). Se README.md. */
'use strict';
const net=require('net'),dgram=require('dgram'),http=require('http'),https=require('https'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const VERSION='1.1.0';
const ARG=(n,d)=>{const i=process.argv.indexOf('--'+n);return i>0&&process.argv[i+1]&&!process.argv[i+1].startsWith('--')?process.argv[i+1]:(i>0?true:d)};
const COMPILED=/^(\/\$bunfs|[A-Za-z]:[\\\/]~BUN)/.test(__dirname); // fristående körbar fil (bun --compile): filer ligger bredvid programmet
const DIR=COMPILED?path.dirname(process.execPath):__dirname,CFGFILE=path.resolve(ARG('config',path.join(DIR,'config.json'))),RECV=path.join(DIR,'config.received.json');
const VERBOSE=!!ARG('verbose',false);
const pad=(n,l=2)=>String(n).padStart(l,'0');
const ts=()=>{const d=new Date();return pad(d.getHours())+':'+pad(d.getMinutes())+':'+pad(d.getSeconds())+'.'+pad(d.getMilliseconds(),3)};
const clients=new Set();let logBuf=[];
function log(m){const l='['+ts()+'] '+m;console.log(l);logBuf.push(l);if(logBuf.length>40)logBuf.shift();wsAll({type:'log',line:l})}
/* ---------- konfig ---------- */
function stripComments(s){let o='',q=false,e=false;for(let i=0;i<s.length;i++){const c=s[i],n=s[i+1];
  if(q){o+=c;if(e)e=false;else if(c==='\\')e=true;else if(c==='"')q=false;continue}
  if(c==='"'){q=true;o+=c;continue}
  if(c==='/'&&n==='/'){while(i<s.length&&s[i]!=='\n')i++;o+='\n';continue}
  if(c==='/'&&n==='*'){i+=2;while(i<s.length&&!(s[i]==='*'&&s[i+1]==='/'))i++;i++;continue}
  o+=c}return o.replace(/,(\s*[}\]])/g,'$1')}
const readJson=f=>JSON.parse(stripComments(fs.readFileSync(f,'utf8')));
let SETT={port:8787,host:'0.0.0.0'},cfg={outputs:[],events:{},feed:{on:false}},cfgSrc='ingen';
function clean(c){c=c||{};return{outputs:Array.isArray(c.outputs)?c.outputs.filter(o=>o&&o.id):[],events:c.events&&typeof c.events==='object'?c.events:{},feed:Object.assign({on:false,type:'udp',host:'127.0.0.1',port:7790,hz:10},c.feed||{})}}
function loadStart(){
  let base=null;try{base=readJson(CFGFILE);SETT=Object.assign(SETT,base);cfg=clean(base);cfgSrc=path.basename(CFGFILE)}catch(e){if(e.code!=='ENOENT')console.log('Kunde inte läsa '+CFGFILE+': '+e.message);else console.log('Ingen config.json hittades – väntar på konfig från Klocka (eller kopiera config.sample.jsonc till config.json).')}
  if(!(base&&base.ignoreReceived)&&fs.existsSync(RECV)){try{const r=readJson(RECV);cfg=clean(r);cfgSrc='senast mottagna från Klocka ('+path.basename(RECV)+')'}catch(e){console.log('Kunde inte läsa '+RECV+': '+e.message)}}
}
loadStart();
if(ARG('port'))SETT.port=+ARG('port');if(process.env.PORT)SETT.port=+process.env.PORT;if(ARG('host')&&ARG('host')!==true)SETT.host=ARG('host');
/* ---------- variabler ---------- */
function subst(str,vars){return String(str==null?'':str).replace(/\{(\w+)(?:\|(\w+))?\}/g,(m,k,f)=>{let v=vars[k];if(v==null)v='';v=String(v);
  if(f==='json')v=JSON.stringify(v).slice(1,-1);else if(f==='url')v=encodeURIComponent(v);else if(f==='upper')v=v.toUpperCase();else if(f==='lower')v=v.toLowerCase();else if(f==='xml')v=v.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');return v})}
const esc=s=>s.replace(/\\r/g,'\r').replace(/\\n/g,'\n').replace(/\\t/g,'\t');
const EOL={none:'',lf:'\n',cr:'\r',crlf:'\r\n'};
const eolOf=o=>EOL[o.eol||(o.type==='udp'||o.type==='osc'?'none':'crlf')]??'';
/* ---------- OSC ---------- */
function ostr(s){const b=Buffer.from(String(s),'utf8');return Buffer.concat([b,Buffer.alloc(4-(b.length%4))])} // alltid minst en nolla, hela 4-byte
function tokens(s){const o=[];const re=/"((?:[^"\\]|\\.)*)"|(\S+)/g;let m;while((m=re.exec(s)))o.push(m[1]!=null?{s:m[1].replace(/\\"/g,'"')}:{t:m[2]});return o}
function oscPacket(addr,argStr){const T=tokens(argStr||''),tags=[','],bufs=[];
  for(const a of T){if(a.s!=null){tags.push('s');bufs.push(ostr(a.s))}else if(/^-?\d+$/.test(a.t)){tags.push('i');const b=Buffer.alloc(4);b.writeInt32BE(parseInt(a.t,10));bufs.push(b)}
    else if(/^-?(\d+\.\d*|\.\d+)$/.test(a.t)){tags.push('f');const b=Buffer.alloc(4);b.writeFloatBE(parseFloat(a.t));bufs.push(b)}
    else if(a.t==='true'||a.t==='false'){tags.push(a.t==='true'?'T':'F')}else{tags.push('s');bufs.push(ostr(a.t))}}
  return Buffer.concat([ostr(addr),ostr(tags.join('')),...bufs])}
/* ---------- sändare ---------- */
const udp=dgram.createSocket('udp4');udp.on('error',e=>log('UDP-fel: '+e.message));
const tcpConns=new Map(); // nyckel host:port -> {sock,q,connecting}
function tcpSend(host,port,data,cb){const k=host+':'+port;let c=tcpConns.get(k);
  if(!c||c.sock.destroyed){c={q:[],ready:false};tcpConns.set(k,c);const s=net.createConnection({host,port});c.sock=s;s.setNoDelay(true);s.setKeepAlive(true,10000);s.setTimeout(4000,()=>{if(!c.ready){s.destroy(new Error('timeout'))}});
    s.on('connect',()=>{c.ready=true;s.setTimeout(0);c.q.splice(0).forEach(x=>s.write(x.d,()=>x.cb&&x.cb()))});
    s.on('error',e=>{c.q.splice(0).forEach(x=>x.cb&&x.cb(e));if(tcpConns.get(k)===c)tcpConns.delete(k);s.destroy()});
    s.on('close',()=>{if(tcpConns.get(k)===c)tcpConns.delete(k)});s.on('data',()=>{})}
  if(c.ready)c.sock.write(data,()=>cb&&cb());else c.q.push({d:data,cb})}
function parseHeaders(h){const o={};String(h||'').split(/;|\n/).forEach(x=>{const i=x.indexOf(':');if(i>0)o[x.slice(0,i).trim()]=x.slice(i+1).trim()});return o}
function httpSend(o,route,vars,cb){let u=subst(route.msg||'',vars);const base=String(o.url||'');if(!/^https?:\/\//i.test(u))u=base.replace(/\/$/,'')+(u&&!/^[\/?#]/.test(u)?'/':'')+u;
  const body=route.body?subst(route.body,vars):'';const method=(o.method||'GET').toUpperCase();let U;try{U=new URL(u)}catch(e){return cb(new Error('Ogiltig URL: '+u),u)}
  const h=Object.assign({},body?{'Content-Type':/^\s*[\[{]/.test(body)?'application/json':'text/plain','Content-Length':Buffer.byteLength(body)}:{},parseHeaders(o.headers));
  const rq=(U.protocol==='https:'?https:http).request(U,{method,headers:h,timeout:4000},r=>{r.resume();r.on('end',()=>cb(null,u,r.statusCode))});
  rq.on('timeout',()=>rq.destroy(new Error('timeout')));rq.on('error',e=>cb(e,u));if(body)rq.write(body);rq.end();return u}
function sendRoute(name,route,vars){const o=cfg.outputs.find(x=>x.id===route.out);if(!o){log(name+': utgång "'+route.out+'" finns inte');return}
  const nm=o.name||o.id,tag=name+' → '+nm+' ';
  const done=what=>e=>log(tag+what+(e?'  FEL: '+e.message:''));
  try{
    if(o.type==='http'){const a=httpSend(o,route,vars,(e,u,code)=>log(tag+'('+(o.method||'GET')+' '+u+(route.body?' '+JSON.stringify(subst(route.body,vars)).slice(0,160):'')+')'+(e?'  FEL: '+e.message:'  → HTTP '+code+(code>=400?'  (FEL)':''))));return a}
    if(o.type==='osc'){const addr=subst(route.msg,vars),args=subst(route.args,vars);udp.send(oscPacket(addr,args),+o.port,o.host,done('(OSC '+o.host+':'+o.port+') '+addr+(args?' '+args:'')));return}
    const msg=esc(subst(route.msg,vars))+eolOf(o),show=JSON.stringify(msg);
    if(o.type==='udp'){udp.send(Buffer.from(msg,'utf8'),+o.port,o.host,done('(UDP '+o.host+':'+o.port+') '+show));return}
    if(o.type==='tcp'||o.type==='rosstalk'){tcpSend(o.host,+o.port,Buffer.from(msg,'utf8'),done('('+(o.type==='rosstalk'?'RossTalk':'TCP')+' '+o.host+':'+o.port+') '+show));return}
    log(tag+'okänd typ "'+o.type+'"')}catch(e){log(tag+'FEL: '+e.message)}}
function fire(name,vars,opt){vars=Object.assign({event:name},vars||{});const R=(cfg.events||{})[name]||[];
  log('HÄNDELSE '+name+(opt&&opt.test?' (test)':'')+(vars.clock?'  klocka '+vars.clock:'')+(vars.score?'  ställning '+vars.score:'')+(vars.team?'  lag '+vars.team:''));
  if(!R.length){log('  ('+name+' har inga mål konfigurerade)');return 0}R.forEach(r=>sendRoute(name,r,vars));return R.length}
/* ---------- datafeed ---------- */
let ST=null,stRecv=0,feedTimer=null,feedCnt=0,feedTcp=null,feedKey='';
const fmt=ms=>{if(ms<60000&&ms>0){const t=Math.floor(ms/100);return Math.floor(t/10)+','+(t%10)}const s=Math.ceil(ms/1000);return Math.floor(s/60)+':'+pad(s%60)};
const fmtP=ms=>{const s=Math.ceil(ms/1000);return Math.floor(s/60)+':'+pad(s%60)};const fmtUp=ms=>{const s=Math.floor(ms/1000);return Math.floor(s/60)+':'+pad(s%60)};
function feedJson(){if(!ST)return null;const now=Date.now(),stale=now-stRecv>3500,d=stale?0:now-ST.ts,S=ST;
  const remain=Math.max(0,S.remainMs-(S.running?d:0)),playing=S.running&&S.penClock;
  const show=S.dir==='up'&&S.period!=='PAUS'?fmtUp(Math.max(0,S.lenMs-remain)):fmt(remain);
  const team=T=>({name:T.name,short:T.short,score:T.goals,shots:T.shots,pens:(T.pens||[]).map(p=>{const l=Math.max(0,p.leftMs-(p.active&&playing?d:0));return{nr:p.nr,kind:p.kind,leftMs:l,left:p.kind==='gm'?'GM':fmtP(l),active:!!p.active}})});
  const lf=x=>x?{team:x.team,leftMs:Math.max(0,x.leftMs-d)}:null;
  return{t:now,stale,running:!!S.running,clock:show,clockMs:remain,period:S.period,periodName:S.periodName,home:team(S.home),away:team(S.away),strength:S.strength||'',timeout:lf(S.timeout),powerbreak:S.pb?{leftMs:Math.max(0,S.pb.leftMs-d)}:null,gid:S.gid||'',mid:S.mid||''}}
function feedStart(){const f=cfg.feed||{};const key=JSON.stringify([f.on,f.type,f.host,f.port,f.hz]);if(key===feedKey)return;feedKey=key;
  clearInterval(feedTimer);feedTimer=null;if(feedTcp){feedTcp.destroy();feedTcp=null}
  if(!f.on){log('Datafeed: av');return}const hz=Math.min(30,Math.max(0.2,+f.hz||10));log('Datafeed: PÅ → '+(f.type||'udp').toUpperCase()+' '+f.host+':'+f.port+' @ '+hz+' Hz (JSON, en rad per paket)');
  const send=()=>{const j=feedJson();if(!j)return;const b=Buffer.from(JSON.stringify(j)+'\n');feedCnt++;if(VERBOSE)log('FEED → '+f.host+':'+f.port+' '+b.length+' byte');
    if((f.type||'udp')==='udp')udp.send(b,+f.port,f.host,e=>{if(e&&!feedErr)feedErr=1,log('Datafeed UDP-fel: '+e.message)});
    else{if(!feedTcp||feedTcp.destroyed){if(feedTcp&&feedTcp.connecting)return;const s=net.createConnection({host:f.host,port:+f.port});feedTcp=s;s.on('error',()=>{});s.on('close',()=>{if(feedTcp===s)feedTcp=null});s.setNoDelay(true);s.on('data',()=>{})}if(feedTcp.writable&&!feedTcp.connecting)feedTcp.write(b)}};
  let feedErr=0;feedTimer=setInterval(send,Math.round(1000/hz))}
setInterval(()=>{if(feedCnt&&!VERBOSE){log('Datafeed: '+feedCnt+' paket senaste 10 s');feedCnt=0}},10000);
/* ---------- LAN-synkhubb ---------- */
const HUB_ON=()=>!!SERVE&&ARG('nolan',false)!==true;
const HUB=require('./lanhub.js')({log,send:(c,o)=>wsSend(c,o),file:path.join(DIR,'lan-state.json'),version:VERSION,fresh:ARG('fresh',false)===true,verbose:()=>VERBOSE,
  /* Adminlogg: mapp (LOG_DIR), sparas LOG_DAYS dagar (standard 180), mappen får högst LOG_MAX_MB MB (standard 500). Kan även sättas i config.json: logDays, logMaxMB, logDir. */
  logDir:path.resolve(DIR,process.env.LOG_DIR||SETT.logDir||'logs'),logDays:+process.env.LOG_DAYS||+SETT.logDays||180,logMaxMB:+process.env.LOG_MAX_MB||+SETT.logMaxMB||500,
  /* PIN till adminsidan och operatörssidor: env ADMIN_PIN eller "adminPin" i config.json (lokal fil, publiceras inte). Tom = ingen PIN. */
  adminPin:String(process.env.ADMIN_PIN||SETT.adminPin||''),secretFile:path.join(DIR,'session.secret')});
/* ---------- WebSocket (egen minimal server, RFC 6455) ---------- */
function wsAccept(req,sock,lan){const key=req.headers['sec-websocket-key'];if(!key){sock.destroy();return}
  sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+crypto.createHash('sha1').update(key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64')+'\r\n\r\n');
  const c={sock,buf:Buffer.alloc(0),frag:null,alive:true,addr:req.socket.remoteAddress,lan:!!lan};sock.setNoDelay(true);
  if(lan)HUB.open(c,req);else{clients.add(c);
  log('Klocka ansluten från '+String(c.addr).replace('::ffff:',''));
  wsSend(c,{type:'hello',version:VERSION,config:cfgSrc,log:logBuf.slice(-12)})}
  sock.on('data',d=>{c.buf=Buffer.concat([c.buf,d]);try{wsParse(c)}catch(e){sock.destroy()}});
  const gone=()=>{if(c.lan){HUB.close(c);return}if(clients.delete(c))log('Klocka frånkopplad ('+String(c.addr).replace('::ffff:','')+')')};sock.on('close',gone);sock.on('error',()=>{});}
function wsFrame(op,payload){const n=payload.length;let h;if(n<126)h=Buffer.from([0x80|op,n]);else if(n<65536){h=Buffer.alloc(4);h[0]=0x80|op;h[1]=126;h.writeUInt16BE(n,2)}else{h=Buffer.alloc(10);h[0]=0x80|op;h[1]=127;h.writeBigUInt64BE(BigInt(n),2)}return Buffer.concat([h,payload])}
function wsSend(c,o){if(c.sock.destroyed)return;try{c.sock.write(wsFrame(1,Buffer.from(JSON.stringify(o))))}catch(e){}}
function wsAll(o){if(!clients.size)return;const f=wsFrame(1,Buffer.from(JSON.stringify(o)));clients.forEach(c=>{try{c.sock.write(f)}catch(e){}})}
function wsParse(c){for(;;){const b=c.buf;if(b.length<2)return;const fin=!!(b[0]&0x80),op=b[0]&15,m=!!(b[1]&0x80);let n=b[1]&127,o=2;
  if(n===126){if(b.length<4)return;n=b.readUInt16BE(2);o=4}else if(n===127){if(b.length<10)return;n=Number(b.readBigUInt64BE(2));o=10}
  if(n>8e6){c.sock.destroy();return}const need=o+(m?4:0)+n;if(b.length<need)return;let p=b.slice(o+(m?4:0),need);
  if(m){const k=b.slice(o,o+4);p=Buffer.from(p);for(let i=0;i<p.length;i++)p[i]^=k[i&3]}c.buf=b.slice(need);
  if(op===8){try{c.sock.write(wsFrame(8,Buffer.alloc(0)))}catch(e){}c.sock.end();return}
  if(op===9){try{c.sock.write(wsFrame(10,p))}catch(e){}continue}if(op===10)continue;
  if(op===1||op===2||op===0){if(op!==0)c.frag={op,parts:[]};if(!c.frag)continue;c.frag.parts.push(p);if(fin){const t=Buffer.concat(c.frag.parts);c.frag=null;onMsg(c,t.toString('utf8'))}}}}
function onMsg(c,t){if(c.lan)return HUB.msg(c,t);let m;try{m=JSON.parse(t)}catch(e){return}
  if(m.type==='event'){const n=fire(String(m.name),m.vars,{test:!!m.test});wsSend(c,{type:'sent',name:m.name,routes:n,test:!!m.test})}
  else if(m.type==='state'){ST=m.state;stRecv=Date.now();ST.ts=Date.now()-(m.age||0)}
  else if(m.type==='config')applyConfig(m.config,c);
  else if(m.type==='ping')wsSend(c,{type:'pong'})}
function applyConfig(n,c){const nc=clean(n);const before=JSON.stringify(cfg);cfg=nc;cfgSrc='mottagen från Klocka '+ts();
  const live=new Set(cfg.outputs.filter(o=>o.type==='tcp'||o.type==='rosstalk').map(o=>o.host+':'+o.port));
  tcpConns.forEach((v,k)=>{if(!live.has(k)){v.sock.destroy();tcpConns.delete(k)}});
  if(JSON.stringify(cfg)!==before){const r=Object.values(cfg.events).reduce((a,x)=>a+(x||[]).length,0);log('Konfig mottagen från Klocka: '+cfg.outputs.length+' utgångar, '+r+' kopplingar'+(cfg.feed.on?', datafeed på':'')+' (sparad som '+path.basename(RECV)+')');
    try{fs.writeFileSync(RECV+'.tmp',JSON.stringify(cfg,null,1));fs.renameSync(RECV+'.tmp',RECV)}catch(e){log('Kunde inte spara '+RECV+': '+e.message)}}
  feedStart();if(c)wsSend(c,{type:'config-ack',outputs:cfg.outputs.length})}
/* ---------- HTTP ---------- */
const MIME={'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.css':'text/css','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.ico':'image/x-icon','.zip':'application/zip','.md':'text/plain; charset=utf-8','.txt':'text/plain; charset=utf-8'};
let SERVE=ARG('serve',SETT.serve);
if(SERVE===true||SERVE==null){SERVE=[path.join(DIR,'site'),path.join(DIR,'..','site')].find(d=>fs.existsSync(path.join(d,'matchklocka')))||null}
else SERVE=path.resolve(DIR,String(SERVE));
if(SERVE&&SETT.serve===false)SERVE=null;
const CORS={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET,POST,OPTIONS','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Private-Network':'true'};
const server=http.createServer((req,res)=>{let u;try{u=new URL(req.url,'http://x')}catch(e){res.writeHead(400);res.end();return}
  const send=(c,o,t)=>{res.writeHead(c,Object.assign({'Content-Type':t||'application/json; charset=utf-8','Cache-Control':'no-store'},CORS));res.end(typeof o==='string'||Buffer.isBuffer(o)?o:JSON.stringify(o))};
  if(req.method==='OPTIONS'){res.writeHead(204,CORS);res.end();return}
  const m=u.pathname.match(/^\/event\/(\w+)$/);
  if(m||u.pathname==='/event'){const run=(name,vars)=>{if(!name)return send(400,{ok:false,error:'saknar event'});const n=fire(name,vars);send(200,{ok:true,event:name,routes:n})};
    if(req.method==='POST'){let b='';req.on('data',d=>{b+=d;if(b.length>1e6)req.destroy()});req.on('end',()=>{let j={};try{j=JSON.parse(b||'{}')}catch(e){}run(m?m[1]:j.event||j.name,Object.assign({},j.vars,m?j:{}))});return}
    const v={};u.searchParams.forEach((x,k)=>v[k]=x);return run(m?m[1]:v.event,v)}
  if(u.pathname==='/state'){const j=feedJson();return send(j?200:404,j||{error:'inget state mottaget än'})}
  /* Adminsidan (/admin, /admin/data, /admin/export): bara privata adresser (LAN/VPN), inga CORS-huvuden */
  if(HUB_ON()&&HUB.admin&&HUB.admin.handle(req,res,u))return;
  if(u.pathname==='/lan/snapshot'&&HUB_ON())return send(200,HUB.snapshot());
  if(u.pathname==='/lan/status'&&HUB_ON()){if(HUB.admin&&!HUB.admin.allowed(req))return send(403,{ok:false,error:'Bara lokalt nätverk/VPN'});return send(200,HUB.status())}
  if(u.pathname==='/status')return send(200,{ok:true,version:VERSION,lan:HUB_ON(),lanEnheter:HUB.clients.size,klockor:clients.size,config:cfgSrc,utgangar:cfg.outputs.length,feed:!!cfg.feed.on,serve:SERVE});
  if(u.pathname==='/config')return send(200,cfg);
  if(!SERVE){if(u.pathname==='/')return send(200,'Matchklocka TV-bridge '+VERSION+'. WebSocket på denna port. Ingen sajt serveras (lägg mappen site/ bredvid bridge.js eller använd --serve).','text/plain; charset=utf-8');return send(404,'Not found','text/plain')}
  /* PIN (om satt): operatörssidor (Klocka, index, OVR, Speaker, På isen, Skott) omdirigeras till /login; displaysidor är öppna */
  if(HUB_ON()&&HUB.admin&&HUB.admin.pageGate(req,res,u))return;
  let p=decodeURIComponent(u.pathname);if(p.endsWith('/'))p+='index.html';const f=path.join(SERVE,path.normalize(p));
  if(!f.startsWith(SERVE)){return send(403,'Forbidden','text/plain')}
  fs.stat(f,(e,st)=>{if(e||!st.isFile()){if(u.pathname==='/'){res.writeHead(302,{Location:'/matchklocka/kontroll.html'});return res.end()}return send(404,'Not found','text/plain')}
    res.writeHead(200,{'Content-Type':MIME[path.extname(f).toLowerCase()]||'application/octet-stream','Cache-Control':'no-store'});fs.createReadStream(f).pipe(res)})});
server.on('upgrade',(req,sock)=>{if((req.headers.upgrade||'').toLowerCase()!=='websocket'){sock.destroy();return}
  let pn='';try{pn=new URL(req.url,'http://x').pathname}catch(e){}
  if(pn==='/lan'){if(!HUB_ON()){sock.destroy();return}wsAccept(req,sock,true)}
  else wsAccept(req,sock,false)});
server.on('error',e=>{if(e.code==='EADDRINUSE')console.log('Port '+SETT.port+' används redan (kör bridgen redan? starta med --port N för annan port).');else console.log('Serverfel: '+e.message);process.exit(1)});
setInterval(()=>{const f=wsFrame(9,Buffer.alloc(0));[...clients,...HUB.clients].forEach(c=>{try{c.sock.write(f)}catch(e){}})},15000);
function hostLocal(cb){const os=require('os');let h=os.hostname();const fin=x=>cb(String(x||'').trim().replace(/\.local$/i,'').replace(/\s+/g,'-'));
  if(process.platform==='darwin'){try{require('child_process').execFile('scutil',['--get','LocalHostName'],{timeout:1500},(e,o)=>fin(!e&&o&&o.trim()?o:h))}catch(e){fin(h)}}else fin(h)}
server.listen(SETT.port,SETT.host,()=>{
  const ips=Object.values(require('os').networkInterfaces()).flat().filter(i=>i&&i.family==='IPv4'&&!i.internal).map(i=>i.address);
  const P=SETT.port;
  hostLocal(hn=>{
  console.log('========================================================');
  console.log(' Matchklocka TV-bridge + LAN-hubb '+VERSION+(COMPILED?'  (fristående körbar fil)':''));
  console.log(' WebSocket:  ws://localhost:'+P+'   (adressen i Klocka → TV-utgång)');
  if(SERVE){
    console.log(' Sajt + LAN-synk (öppna sidorna från dessa adresser – INTE från github.io):');
    ips.forEach(i=>console.log('   http://'+i+':'+P+'/                      startsida'));
    if(hn)console.log('   http://'+hn+'.local:'+P+'/               (namn istället för IP; fungerar på Mac/iPad/iPhone/Windows 10+, ej alla Android)');
    console.log(' Per enhet (byt ut adressen mot en av ovan):');
    const B=(ips[0]?'http://'+ips[0]:'http://localhost')+':'+P;
    [['Klocka (EN enhet)','/matchklocka/kontroll.html'],['På isen','/matchklocka/paisen.html'],['OVR Rapport','/matchklocka/ovr.html'],['Speaker','/speaker.html'],/* Speaker U18 pausad 2026-10-28: ['Speaker U18','/speaker-u18.html'], */['Jumbotron','/matchklocka/jumbotron.html'],['Domarskärm','/matchklocka/domare.html'],['Omklädningsrum','/matchklocka/omkladningsrum.html'],['Skott & puckinnehav','/matchklocka/skott.html']].forEach(([n,u])=>console.log('   '+(n+'                      ').slice(0,22)+B+u));
    console.log(' LAN-synk: '+(HUB_ON()?'PÅ – status: '+B+'/lan/status':'AV (--nolan)'));
    if(HUB_ON())console.log(' Admin/logg: '+B+'/admin   (bara LAN/VPN'+((process.env.ADMIN_PIN||SETT.adminPin)?', PIN krävs':', INGEN PIN satt')+'; logg i '+path.resolve(DIR,process.env.LOG_DIR||SETT.logDir||'logs')+')');
    if(!ips.length)console.log(' OBS: ingen nätverksadress hittades – anslut datorn till nätverket (router/switch) och starta om.');
  }else console.log(' Ingen sajt hittades (lägg mappen site/ bredvid programmet) – LAN-synk är av.');
  console.log(' Konfig:     '+cfgSrc+' – '+cfg.outputs.length+' utgångar');
  console.log(' Alla utskick loggas nedan. Avsluta med Ctrl+C.');
  console.log('========================================================')});
  feedStart()});
process.on('uncaughtException',e=>log('Oväntat fel: '+e.message));
