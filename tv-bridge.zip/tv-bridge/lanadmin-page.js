/* HTML för /admin (hålls i en JS-modul så att den följer med i den fristående Mac-filen). Klient-JS använder inga backticks. */
module.exports=String.raw`<!doctype html><html lang="sv"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin – Matchklocka LAN</title>
<style>
:root{--bg:#0f1216;--card:#181d24;--line:#2a323d;--tx:#e8edf3;--mut:#8b97a6;--ok:#2fb35a;--warn:#f0b400;--bad:#d9383c}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font:14px/1.4 system-ui,Arial,sans-serif;padding:14px;max-width:1500px;margin:auto}
h1{font-size:20px;margin:0 0 2px}h2{font-size:15px;margin:0 0 8px;letter-spacing:.3px}.sub{color:var(--mut);font-size:12px}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:12px 14px;margin:12px 0}
.row{display:flex;gap:18px;flex-wrap:wrap;align-items:center}
.pill{display:inline-block;padding:5px 12px;border-radius:14px;font-weight:700;color:#fff}.pill.ok{background:var(--ok)}.pill.bad{background:var(--bad)}.pill.warn{background:var(--warn);color:#000}
table{border-collapse:collapse;width:100%}th,td{text-align:left;padding:5px 8px;border-bottom:1px solid var(--line);vertical-align:top}th{color:var(--mut);font-weight:600;font-size:12px;white-space:nowrap}
.dot{display:inline-block;width:12px;height:12px;border-radius:50%;margin-right:6px;vertical-align:-1px}.dot.ok{background:var(--ok)}.dot.varning{background:var(--warn)}.dot.tyst{background:var(--bad)}
tr.varning td{background:#2d2700}tr.tyst td{background:#3a1416}
.mono{font-family:ui-monospace,Menlo,Consolas,monospace}.mut{color:var(--mut)}.nw{white-space:nowrap}
.ctl{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:8px}
select,input,button{background:#0f1216;color:var(--tx);border:1px solid var(--line);border-radius:6px;padding:5px 8px;font:inherit}button{cursor:pointer}button:hover{border-color:#556}
a{color:#6db3ff}
#log tr.avvikelse td{background:#4a3a00;color:#ffe9a6}#log tr.avvikelse td.t{border-left:4px solid var(--warn)}#log tr.avvikelse.rod td{background:#4a1416;color:#ffd0d0}
#log tr.m td.x{font-weight:700}#log tr.sys td{color:var(--mut)}#log tr{cursor:pointer}
.det{white-space:pre-wrap;color:var(--mut);font-size:12px}
#banner{display:none;background:#4a3a00;border:1px solid var(--warn);color:#ffe9a6;border-radius:8px;padding:8px 12px;margin:10px 0;cursor:pointer;font-weight:600}
.tag{font-size:11px;padding:1px 6px;border-radius:8px;background:#2a323d;color:var(--mut)}.tag.avv{background:var(--warn);color:#000}
@media print{body{background:#fff;color:#000}.card,.noprint{display:none}#logcard{display:block;border:0;background:#fff}#logcard *{color:#000!important}#log tr.avvikelse td{background:#fff3c4!important}th{color:#000}.ctl{display:none}}
</style></head><body>
<div class="row noprint" style="justify-content:space-between"><div><h1>Admin – Piteå HC Matchklocka</h1><div class="sub" id="hdr">laddar…</div></div><div class="row"><form id="lo" method="post" action="/admin/logout" style="display:none;margin:0"><button type="submit">Logga ut</button></form><div id="conn" class="pill warn">ansluter…</div></div></div>
<div id="banner" class="noprint"></div>

<div class="card" id="sparcard" style="display:none"><h2>PIN-spärrar <span class="sub">(för många felaktiga PIN-försök, spärr 1 min)</span></h2><table><thead><tr><th>IP-adress</th><th>Återstår</th><th></th></tr></thead><tbody id="spar"></tbody></table></div>

<div class="card"><h2>Klocka</h2><div class="row" id="klocka">…</div></div>

<div class="card"><h2>Anslutna enheter <span class="sub" id="ndev"></span></h2>
<table><thead><tr><th>Status</th><th>Sida</th><th>Roll</th><th>IP-adress</th><th>Enhet</th><th>Ansluten sedan</th><th>Senaste meddelande</th><th>Klockskev</th></tr></thead><tbody id="devs"></tbody></table>
<div class="sub" style="margin-top:6px"><span class="dot ok"></span>grön &lt; 8 s &nbsp; <span class="dot varning"></span>gul 8–20 s &nbsp; <span class="dot tyst"></span>röd &gt; 20 s sedan senaste meddelande (enheterna pingar var 4:e sekund). Klockskev = hur mycket enhetens egen klocka avviker från hubben (kompenseras automatiskt).</div></div>

<div class="card"><h2>Hubben och adresser</h2><div class="row" style="margin-bottom:8px"><div>Hubbens adresser: <span id="addrs" class="mono"></span></div><div>Datornamn: <span id="hostn" class="mono"></span></div></div>
<div class="ctl">Visa länkar för: <select id="base"></select></div>
<table><thead><tr><th>Skärm</th><th>Adress att öppna på enheten</th></tr></thead><tbody id="links"></tbody></table></div>

<div class="card" id="logcard"><h2>Logg <span class="sub" id="nlog"></span></h2>
<div class="ctl noprint">
<select id="f"><option value="alla">Alla händelser</option><option value="match">Bara matchhändelser</option><option value="avv">Bara avvikelser</option><option value="anslutning">Anslutningar</option><option value="synk">Synk</option><option value="klocka">Klocka</option></select>
<input id="q" placeholder="Sök i text…" size="18">
<label><input type="checkbox" id="asc"> Äldst först</label>
<label>Dag: <input type="date" id="dag"></label><button id="live" title="Tillbaka till livevy">Idag / live</button>
<span class="mut">|</span>
<a id="csvm" href="#">Ladda ner matchhändelser (CSV)</a> <a id="csva" href="#">Alla händelser (CSV)</a> <button id="prn">Skriv ut</button>
</div>
<table><thead><tr><th>Tid</th><th>Matchtid</th><th>Typ</th><th>Lag</th><th>Nr</th><th>Straff</th><th>Händelse</th></tr></thead><tbody id="log"></tbody></table>
<div class="sub" id="loginfo" style="margin-top:8px"></div></div>

<script>
var S={ev:[],boot:0,seq:0,d:null,today:'',view:'live',day:[]};
var $=function(i){return document.getElementById(i)};
function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function dur(ms){var s=Math.round(ms/1000);return s<60?s+' s':s<3600?Math.floor(s/60)+' min '+('0'+s%60).slice(-2)+' s':Math.floor(s/3600)+' h '+('0'+Math.floor(s/60)%60).slice(-2)+' min'}
var TF=new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Stockholm',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}),DF=new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Stockholm',year:'numeric',month:'2-digit',day:'2-digit'});
function bytes(b){return b<1024?b+' B':b<1048576?(b/1024).toFixed(1)+' kB':(b/1048576).toFixed(1)+' MB'}
var PAGELIST=[['Klocka (EN enhet)','/matchklocka/kontroll.html'],['På isen – hemma','/matchklocka/paisen.html?lag=hemma'],['På isen – borta','/matchklocka/paisen.html?lag=borta'],['OVR Rapport','/matchklocka/ovr.html'],['Speaker','/speaker.html'],['Jumbotron','/matchklocka/jumbotron.html'],['Domarskärm','/matchklocka/domare.html'],['Omklädningsrum','/matchklocka/omkladningsrum.html'],['Skott & puckinnehav','/matchklocka/skott.html']];
function skewTxt(v){if(v==null)return '–';if(Math.abs(v)>=10000)return (v<0?'−':'+')+dur(Math.abs(v));return (v>0?'+':v<0?'−':'')+Math.abs(v)+' ms'}
function poll(){
  fetch('/admin/data?since='+S.seq+'&boot='+S.boot,{cache:'no-store'}).then(function(r){if(r.status===401){location.reload();throw new Error(401)}if(!r.ok)throw new Error(r.status);return r.json()}).then(function(d){
    S.d=d;S.today=DF.format(new Date(d.now));
    if(d.reset){S.ev=d.events}else{S.ev=S.ev.concat(d.events)}if(S.ev.length>4000)S.ev=S.ev.slice(-3000);
    S.seq=d.seq;S.boot=d.boot;$('lo').style.display=d.pinOn?'':'none';$('conn').className='pill ok';$('conn').textContent='● live';render()
  }).catch(function(e){$('conn').className='pill bad';$('conn').textContent='● ingen kontakt med hubben'})}
function unlock(ip){fetch('/admin/unlock',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'ip='+encodeURIComponent(ip)}).then(function(r){if(r.status===401)location.reload();else poll()})}
function drawSpar(d){var l=d.spar||[],c=$('sparcard');c.style.display=l.length?'':'none';if(!l.length){$('spar').innerHTML='';return}
  $('spar').innerHTML=l.map(function(x){return '<tr><td class="mono">'+esc(x.ip)+'</td><td>'+x.kvarS+' s</td><td><button class="unl" data-ip="'+esc(x.ip)+'">Lås upp</button></td></tr>'}).join('')+(l.length>1?'<tr><td colspan="3"><button class="unl" data-ip="alla">Lås upp alla</button></td></tr>':'')}
document.addEventListener('click',function(e){var b=e.target;if(b&&b.className==='unl')unlock(b.getAttribute('data-ip'))});
function render(){var d=S.d;if(!d)return;drawSpar(d);
  $('hdr').textContent='Hubb '+d.version+' · igång '+dur(d.uptimeMs)+' · uppdaterad '+TF.format(new Date(d.now))+' (svensk tid)';
  var k=d.klocka,h='';
  h+='<div><span class="pill '+(k.connected?(k.antal>1?'warn':'ok'):'bad')+'">'+(k.connected?'● Klocka ansluten'+(k.antal>1?' ('+k.antal+' st – BARA EN ska finnas!)':''):'● Klocka EJ ansluten')+'</span></div>';
  h+='<div><span class="mut">Senast hörd från Klocka:</span> <b>'+(k.lastMs==null?'–':dur(k.lastMs)+' sedan')+'</b></div>';
  h+='<div><span class="mut">Senaste läge mottaget:</span> <b>'+(k.stateAgeMs==null?'–':dur(k.stateAgeMs)+' sedan')+'</b></div>';
  if(k.match)h+='<div><span class="mut">Match:</span> <b>'+esc(k.match)+'</b> · '+esc(k.score)+' · '+esc(k.kt)+' · klockan '+(k.running?'<b style="color:#6fe08f">går</b>':'står still')+'</div>';
  $('klocka').innerHTML=h;
  var rows=d.devices.slice().sort(function(a,b){return(b.roll==='klocka')-(a.roll==='klocka')||a.namn.localeCompare(b.namn,'sv')||a.ip.localeCompare(b.ip)});
  $('ndev').textContent='('+rows.length+')';
  $('devs').innerHTML=rows.map(function(r){var since=TF.format(new Date(d.now-r.sinceMs));
    return '<tr class="'+r.status+'"><td class="nw"><span class="dot '+r.status+'"></span>'+(r.status==='ok'?'OK':r.status==='varning'?'sen':'TYST')+'</td><td><b>'+esc(r.namn)+'</b><div class="mut mono" style="font-size:11px">'+esc(r.page)+(r.ro&&d.pinOn?' · skrivskyddad':'')+'</div></td><td>'+esc(r.roll)+'</td><td class="mono">'+esc(r.ip)+'</td><td class="mut">'+esc(r.enhet)+'</td><td class="nw">'+since+' <span class="mut">('+dur(r.sinceMs)+')</span></td><td class="nw"><b>'+(r.lastMs<1000?'&lt; 1 s':dur(r.lastMs))+'</b> sedan</td><td class="nw '+(r.skew!=null&&Math.abs(r.skew)>30000?'':'mut')+'">'+skewTxt(r.skew)+'</td></tr>'}).join('')||'<tr><td colspan="8" class="mut">Inga enheter anslutna.</td></tr>';
  var hub=d.hub,hosts=[location.host].concat(hub.ips.map(function(i){return i+':'+hub.port}));hosts=hosts.filter(function(x,i){return hosts.indexOf(x)===i});
  $('addrs').innerHTML=hub.ips.length?hub.ips.map(function(i){return esc(i+':'+hub.port)}).join(' &nbsp; '):'(ingen nätverksadress)';$('hostn').textContent=hub.host+'.local:'+hub.port;
  var sel=$('base'),cur=sel.value;if(sel.getAttribute('data-h')!==hosts.join('|')){sel.setAttribute('data-h',hosts.join('|'));sel.innerHTML=hosts.map(function(x){return '<option>'+esc(x)+'</option>'}).join('');if(cur&&hosts.indexOf(cur)>=0)sel.value=cur}
  var b=sel.value||hosts[0];
  $('links').innerHTML=PAGELIST.map(function(p){var u='http://'+b+p[1];return '<tr><td>'+esc(p[0])+'</td><td class="mono"><a href="'+esc(u)+'" target="_blank">'+esc(u)+'</a></td></tr>'}).join('');
  var L=d.log;$('loginfo').innerHTML='Loggmapp: <span class="mono">'+esc(L.dir)+'</span> · sparas <b>'+L.days+'</b> dagar (äldre raderas automatiskt vid start och dagligen), tak <b>'+L.maxMB+' MB</b> · nu <b>'+bytes(L.bytes)+'</b> i '+L.files+' fil'+(L.files===1?'':'er')+(L.oldest?' (äldsta '+esc(L.oldest)+')':'')+' · tidsstämplar: Europe/Stockholm';
  var cutoff=d.now-3600000,n=S.ev.filter(function(e){return e.niv==='avvikelse'&&e.ts>cutoff}).length,bn=$('banner');
  if(n){bn.style.display='block';bn.textContent='⚠ '+n+' avvikelse'+(n>1?'r':'')+' senaste timmen – klicka för att visa'}else bn.style.display='none';
  drawLog()}
function drawLog(){var src=S.view==='live'?S.ev:S.day,f=$('f').value,q=$('q').value.toLowerCase(),asc=$('asc').checked;
  var l=src.filter(function(e){if(f==='match'&&!e.m)return false;if(f==='avv'&&e.niv!=='avvikelse')return false;if(f!=='alla'&&f!=='match'&&f!=='avv'&&e.typ!==f)return false;
    if(q&&(e.text+' '+e.lag+' '+e.nr+' '+e.typ).toLowerCase().indexOf(q)<0)return false;return true});
  if(!asc)l=l.slice().reverse();var tot=l.length;l=l.slice(0,asc?l.length:500);if(asc&&l.length>1500)l=l.slice(-1500);
  $('nlog').textContent='('+tot+(S.view==='live'?'':' – dag '+$('dag').value)+')';
  var lastDag='';
  $('log').innerHTML=l.map(function(e,i){var dd=e.dag!==S.today?'<span class="mut">'+esc(e.dag.slice(5))+'</span> ':'';
    var cls=(e.niv==='avvikelse'?'avvikelse':'')+(e.m?' m':'')+(e.typ==='system'?' sys':'');
    var det=e.d?'<tr class="det" style="display:none"><td colspan="7"><div class="det">'+esc(JSON.stringify(e.d,null,1))+(e.match?'\nMatch: '+esc(e.match):'')+'</div></td></tr>':'';
    return '<tr class="'+cls+'" onclick="var n=this.nextSibling;if(n&&n.className===\'det\')n.style.display=n.style.display===\'none\'?\'\':\'none\'"><td class="t nw mono">'+dd+esc(e.tid)+'</td><td class="nw mono x">'+esc(e.kt||'')+'</td><td class="nw">'+(e.niv==='avvikelse'?'<span class="tag avv">AVVIKELSE</span> ':'')+'<span class="tag">'+esc(e.typ)+'</span></td><td class="nw">'+esc(e.lag||'')+'</td><td class="nw">'+esc(e.nr?'#'+e.nr:'')+'</td><td class="nw">'+esc(e.straff||'')+'</td><td>'+(e.niv==='avvikelse'?'⚠ ':'')+esc(e.text)+'</td></tr>'+det}).join('')||'<tr><td colspan="7" class="mut">Inga händelser.</td></tr>';
  var dag=$('dag').value||S.today;$('csvm').href='/admin/export?dag='+dag+'&match=1';$('csva').href='/admin/export?dag='+dag+'&match=0'}
function loadDay(){var dag=$('dag').value;if(!dag||dag===S.today){S.view='live';drawLog();return}
  fetch('/admin/export?dag='+dag+'&format=json&match=0').then(function(r){return r.json()}).then(function(j){S.view='day';S.day=j.events.map(function(e,i){e.id=i;return e});drawLog()})}
$('f').onchange=$('q').oninput=$('asc').onchange=drawLog;$('base').onchange=render;$('dag').onchange=loadDay;
$('live').onclick=function(){$('dag').value=S.today;S.view='live';drawLog()};
$('prn').onclick=function(){window.print()};
$('banner').onclick=function(){$('f').value='avv';$('dag').value=S.today;S.view='live';drawLog();$('logcard').scrollIntoView()};
poll();setInterval(poll,1000);
</script></body></html>`;
