/* Admin-/statussida + logg för LAN-hubben (del av bridge.js, inga beroenden).
   - Händelselogg: JSONL per dag (logs/YYYY-MM-DD.jsonl, dygnsgräns enligt Europe/Stockholm) + de senaste i minnet.
   - Spelhändelser härleds genom att jämföra Klockas läge före/efter varje uppdatering (Klocka behöver inte ändras).
   - 'avvikelse' = något ovanligt (konflikter, hopp i klockan, resultat som minskar m.m.) – markeras tydligt på sidan.
   - Sidan /admin, /admin/data och /admin/export svarar bara till privata adresser (LAN/VPN), och kräver PIN om ADMIN_PIN/adminPin är satt. */
'use strict';
const fs=require('fs'),path=require('path'),os=require('os'),crypto=require('crypto');
const PAGEHTML=require('./lanadmin-page.js');
const KLOCKA_KEY='matchklocka_state_v1';
const PAGES={kontroll:'Klocka',paisen:'På isen',ovr:'OVR Rapport',speaker:'Speaker','speaker-u18':'Speaker U18',kommentator:'KommentatorApp',jumbotron:'Jumbotron',domare:'Domarskärm',omkladningsrum:'Omklädningsrum',skott:'Skott & puckinnehav',tv:'TV-utgång','ndi-mal':'NDI målgrafik','ndi-scorebug':'NDI scorebug','ndi-utvisning':'NDI utvisningsgrafik',index:'Startsida'};
const STALE_WARN=8000,STALE_BAD=20000,GAP_MS=12000,SKEW_WARN=30000,FLAP_N=5,FLAP_MS=300000;
let DTF=null;try{DTF=new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Stockholm',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'})}catch(e){}
const z2=n=>String(n).padStart(2,'0');
const sthlm=ts=>{if(DTF){try{const p={};DTF.formatToParts(new Date(ts)).forEach(x=>p[x.type]=x.value);return{dag:p.year+'-'+p.month+'-'+p.day,tid:p.hour+':'+p.minute+':'+p.second}}catch(e){}}
  const d=new Date(ts);return{dag:d.getFullYear()+'-'+z2(d.getMonth()+1)+'-'+z2(d.getDate()),tid:z2(d.getHours())+':'+z2(d.getMinutes())+':'+z2(d.getSeconds())}};
/* Privata adresser: 127/8, 10/8, 172.16/12, 192.168/16, 100.64/10 (Tailscale), 169.254/16, ::1, fe80::/10, fc00::/7 */
function privateIp(a){a=String(a||'').replace(/^::ffff:/i,'').toLowerCase();
  const m=a.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/);
  if(m){const x=+m[1],y=+m[2];return x===127||x===10||(x===172&&y>=16&&y<=31)||(x===192&&y===168)||(x===100&&y>=64&&y<=127)||(x===169&&y===254)}
  return a==='::1'||/^fe[89ab]/.test(a)||/^f[cd]/.test(a)}
function uaLabel(ua){ua=String(ua||'');const os_=/iPad/.test(ua)?'iPad':/iPhone/.test(ua)?'iPhone':/Android/.test(ua)?'Android':/CrOS/.test(ua)?'ChromeOS':/Macintosh/.test(ua)?'Mac':/Windows/.test(ua)?'Windows':/Linux/.test(ua)?'Linux':'';
  const br=/Edg\//.test(ua)?'Edge':/Firefox\//.test(ua)?'Firefox':/Chrome\//.test(ua)?'Chrome':/Safari\//.test(ua)?'Safari':'';return[os_,br].filter(Boolean).join(' · ')}
const fmtT=ms=>{const s=Math.ceil(Math.max(0,ms)/1000);return Math.floor(s/60)+':'+z2(s%60)};
const fmtDur=ms=>{const s=Math.round(ms/1000);return s<60?s+' s':s<3600?Math.floor(s/60)+' min '+z2(s%60)+' s':Math.floor(s/3600)+' h '+z2(Math.floor(s/60)%60)+' min'};
const CSVH=['Datum','Tid','Typ','Nivå','Match','Period','Klocktid','Lag','Nr','Straff','Text'];
const csvCell=v=>{v=v==null?'':String(v);return /[";\r\n]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v};

module.exports=function create(o){
  const log=o.log||(()=>{}),clients=o.clients,getKlocka=o.getKlocka,VERSION=o.version||'';
  const PIN=String(o.pin==null?'':o.pin).trim(); /* tom = ingen PIN (som tidigare) */
  const DIR=o.dir,DAYS=Math.max(1,+o.days||180),MAXMB=Math.max(1,+o.maxMB||500);
  const boot=Date.now();let seq=0;const ring=[];const RING=1000;
  let lastState=null;const cond=new Set(),flap=new Map(),throttle=new Map();
  const dayFile=d=>path.join(DIR,d+'.jsonl');
  const nameOf=c=>c.role==='klocka'?'Klocka':(PAGES[c.page]||c.page||'okänd sida')+(c.lag?' ('+c.lag+')':'');
  /* ---------- logg ---------- */
  function add(e){const ts=Date.now(),t=sthlm(ts);
    e=Object.assign({ts,dag:t.dag,tid:t.tid,typ:'system',niv:'info',m:0,text:''},e);
    const line=JSON.stringify(e);e.id=++seq;ring.push(e);if(ring.length>RING)ring.shift();
    try{fs.mkdirSync(DIR,{recursive:true});fs.appendFileSync(dayFile(e.dag),line+'\n')}catch(err){if(!add.warned){add.warned=1;log('Admin-logg: kan inte skriva i '+DIR+': '+err.message)}}
    return e}
  const limited=(key,ms)=>{const n=Date.now(),t=throttle.get(key)||0;if(n-t<ms)return true;throttle.set(key,n);return false};
  function loadRecent(){try{const files=fs.readdirSync(DIR).filter(f=>/^\d{4}-\d{2}-\d{2}\.jsonl$/.test(f)).sort().slice(-2);let all=[];
    files.forEach(f=>fs.readFileSync(path.join(DIR,f),'utf8').split('\n').forEach(l=>{if(l){try{all.push(JSON.parse(l))}catch(e){}}}));
    all.slice(-300).forEach(e=>{e.id=++seq;ring.push(e)})}catch(e){}}
  /* ---------- gallring: äldre än DAYS dygn bort, sedan äldsta först tills mappen är under MAXMB ---------- */
  function files(){try{return fs.readdirSync(DIR).filter(f=>/^\d{4}-\d{2}-\d{2}\.jsonl$/.test(f)).sort().map(f=>{let s=0;try{s=fs.statSync(path.join(DIR,f)).size}catch(e){}return{f,size:s,dag:f.slice(0,10)}})}catch(e){return[]}}
  function cleanup(){const L=files(),gone=[];const cut=sthlm(Date.now()-DAYS*864e5).dag;
    L.forEach(x=>{if(x.dag<cut){try{fs.unlinkSync(path.join(DIR,x.f));gone.push(x.f);x.del=1}catch(e){}}});
    let rest=L.filter(x=>!x.del),tot=rest.reduce((a,x)=>a+x.size,0);const today=sthlm(Date.now()).dag;
    while(tot>MAXMB*1048576&&rest.length&&rest[0].dag!==today){const x=rest.shift();try{fs.unlinkSync(path.join(DIR,x.f));gone.push(x.f);tot-=x.size}catch(e){break}}
    if(gone.length)add({typ:'system',text:'Loggen gallrad: '+gone.length+' fil'+(gone.length>1?'er':'')+' raderade ('+gone[0]+(gone.length>1?' … '+gone[gone.length-1]:'')+'); sparas '+DAYS+' dagar, max '+MAXMB+' MB',d:{files:gone}});
    return gone}
  const stats=()=>{const L=files();return{dir:DIR,days:DAYS,maxMB:MAXMB,bytes:L.reduce((a,x)=>a+x.size,0),files:L.length,oldest:L[0]?L[0].dag:null}};
  /* ---------- tid i matchen ---------- */
  const perLen=(s,p)=>((p==='PAUS'?s.len.PAUS:/^OT/.test(p)?s.len.OT:s.len.P)||20)*60000;
  const cur=(s,at)=>s.clock.running?s.clock.remain-(at-s.clock.startedAt):s.clock.remain;
  const unz=x=>String(x||'').replace(/^0(\d:)/,'$1');
  /* Klocktid som den visas på klockan (nedräkning eller uppräkning), t.ex. 'P2 12:34' */
  function kt(s,at,ev){const up=s.dir==='up'&&s.period!=='PAUS';
    if(ev&&ev.per)return ev.per+' '+unz(up?ev.el:ev.rem);
    const r=Math.max(0,cur(s,at));return s.period+' '+(up?fmtT(perLen(s,s.period)-r):fmtT(r))}
  /* ---------- Klockas läge: jämför före/efter ---------- */
  function diffState(p,n){
    const at=+n.v||Date.now(),mt=n.home+' – '+n.away,team=t=>t?n.away:n.home;
    const G=(typ,text,x)=>add(Object.assign({typ,text,m:1,match:mt,per:n.period,kt:kt(n,at)},x||{}));
    const C=(name,on,typ,text,x)=>{if(on&&!cond.has(name)){cond.add(name);G(typ,text,Object.assign({niv:'avvikelse'},x))}else if(!on)cond.delete(name)};
    if(p.mid&&n.mid&&p.mid!==n.mid){const empty=!(n.ev||[]).length&&!n.goals[0]&&!n.goals[1],had=(p.ev||[]).length||p.goals[0]||p.goals[1];
      if(empty)G('nollställning','Nollställning / ny match: '+mt+(had?' (föregående ställning '+p.goals.join('–')+', '+p.period+')':''),{niv:had&&p.period!=='SLUT'?'avvikelse':'info',per:'',kt:''});
      else G('nollställning','Ny match laddad: '+mt+' ('+n.goals.join('–')+')',{per:'',kt:''});
      cond.clear();return}
    const pm=new Map((p.ev||[]).map(e=>[e.id,e])),nm=new Map((n.ev||[]).map(e=>[e.id,e]));
    /* period */
    if(p.period!==n.period){const R=x=>x==='P1'?1:x==='P2'?2:x==='P3'?3:/^OT/.test(x)?4:0,a=R(p.period),b=R(n.period);
      const back=(a&&b&&b<a)||(p.period==='SLUT'&&b>0);
      G('period','Period: '+p.period+' → '+n.period+(back?' (bakåt!)':''),{niv:back?'avvikelse':'info',d:{från:p.period,till:n.period}})}
    /* klocka start/stopp */
    if(p.clock.running!==n.clock.running)G('klocka',n.clock.running?'Klockan startad':'Klockan stoppad',{d:{remainMs:Math.round(cur(n,at))}});
    /* hopp i klockan (manuell justering): jämför var klockan skulle varit utan ändringen */
    if(p.period===n.period){const d=cur(n,at)-cur(p,at);
      if(Math.abs(d)>1500){const back=d>0,big=Math.abs(d)>60000;
        G('klocka','Klockan ändrad manuellt: '+kt(p,at)+' → '+kt(n,at)+' ('+(d>0?'+':'−')+fmtDur(Math.abs(d))+(back?', tillbaka i tid':'')+')',{niv:back||big?'avvikelse':'info',d:{deltaMs:Math.round(d),från:Math.round(cur(p,at)),till:Math.round(cur(n,at))}})}}
    /* mål (via händelselistan) */
    const goalDelta=[0,0];
    (n.ev||[]).forEach(e=>{const pe=pm.get(e.id);
      if(e.typ==='Mål'){
        if(!pe&&!e.del){goalDelta[e.t]++;G('mål','Mål '+team(e.t)+' – ställning '+e.sH+'–'+e.sA,{lag:team(e.t),per:e.per,kt:kt(n,at,e),d:{sH:e.sH,sA:e.sA,el:e.el,rem:e.rem,gid:e.gid}})}
        else if(pe&&e.del&&!pe.del){goalDelta[e.t]--;G('mål','Mål BORTTAGET: '+team(e.t)+' (var '+pe.sH+'–'+pe.sA+', '+kt(n,at,e)+')',{niv:'avvikelse',lag:team(e.t),per:e.per,kt:kt(n,at,e),d:{sH:e.sH,sA:e.sA}})}}
      else if(e.typ==='Utvisning'){const x={lag:team(e.t),nr:e.nr||'',straff:(e.lbl||e.min||'')+(e.lbl&&e.min&&String(e.lbl)!==String(e.min)?' ('+e.min+' min)':'')+(e.coin?' samtidig':''),per:e.per,kt:kt(n,at,e)};
        if(!pe&&!e.del)G('utvisning','Utvisning '+x.lag+(x.nr?' #'+x.nr:'')+' '+(e.min||e.lbl||'')+' min'+(e.coin?' (samtidig)':''),Object.assign(x,{d:{min:e.min,lbl:e.lbl,coin:!!e.coin,el:e.el,rem:e.rem}}));
        else if(pe&&e.del&&!pe.del)G('utvisning','Utvisning BORTTAGEN: '+x.lag+(x.nr?' #'+x.nr:'')+' '+(e.min||e.lbl||'')+' min',Object.assign(x,{niv:'avvikelse'}));
        else if(pe&&!e.del&&(pe.nr!==e.nr||pe.lbl!==e.lbl||pe.min!==e.min||pe.t!==e.t))G('utvisning','Utvisning ÄNDRAD efteråt: '+(pe.nr?'#'+pe.nr:'')+' '+pe.min+' min → '+(e.nr?'#'+e.nr:'')+' '+e.min+' min',Object.assign(x,{niv:'avvikelse'}));
        if(pe&&e.end&&!pe.end&&!e.del)G('utvisning','Utvisning slut '+x.lag+(x.nr?' #'+x.nr:''),{lag:x.lag,nr:x.nr,per:e.end.per||n.period,kt:e.end.per?kt(n,at,e.end):kt(n,at)})}
      if(pe&&e.typ==='Mål'&&!e.del&&(pe.t!==e.t))G('mål','Mål FLYTTAT till annat lag efteråt',{niv:'avvikelse',lag:team(e.t),per:e.per,kt:kt(n,at,e)})});
    pm.forEach((e,id)=>{if(!nm.has(id))G(e.typ==='Mål'?'mål':'utvisning',(e.typ||'Händelse')+' saknas i listan (raderad ur historiken): '+team(e.t)+' '+(e.per||''),{niv:'avvikelse',lag:team(e.t)})});
    /* resultat som inte stämmer med händelserna / minskar */
    [0,1].forEach(t=>{const d=n.goals[t]-p.goals[t];
      if(d!==goalDelta[t])G('mål','Resultat '+team(t)+': '+p.goals[t]+' → '+n.goals[t]+(d<0?' (resultatet MINSKADE)':'')+' utan matchande målhändelse',{niv:'avvikelse',lag:team(t),d:{från:p.goals[t],till:n.goals[t]}})});
    /* timeout / powerbreak */
    const cd=x=>x&&x.endsAt?x.endsAt-at:0;
    if(n.timeout&&!p.timeout)G('timeout','Timeout '+team(n.timeout.team),{lag:team(n.timeout.team)});
    else if(!n.timeout&&p.timeout)G('timeout','Timeout slut/avbruten',{m:0,lag:team(p.timeout.team)});
    if(n.pb&&!p.pb)G('powerbreak','Powerbreak startad');
    else if(!n.pb&&p.pb)G('powerbreak','Powerbreak slut/avbruten',{m:0});
    /* tillstånd som inte borde uppstå (loggas när det börjar gälla) */
    const r=cur(n,at);
    C('pastzero',n.clock.running&&r<-3000,'klocka','Klockan går förbi 0:00 (stoppades inte)');
    C('slutrun',n.clock.running&&n.period==='SLUT','klocka','Klockan går fast perioden är SLUT');
    C('pausetimer',n.clock.running&&/^(P\d|OT)/.test(n.period)&&(cd(n.timeout)>0||cd(n.pb)>0),'klocka','Klockan går under pågående timeout/powerbreak');
    C('overlen',n.clock.remain>perLen(n,n.period)+1000,'klocka','Klockans tid ('+fmtT(n.clock.remain)+') är längre än '+n.period+'s längd ('+fmtT(perLen(n,n.period))+')')}
  function klockaState(c,e){let n=null;try{n=JSON.parse(e.v)}catch(err){add({typ:'avvikelse',niv:'avvikelse',text:'Klockas läge gick inte att tolka (ogiltig JSON)'});return}
    if(!n||!n.clock||!Array.isArray(n.goals))return;
    const p=lastState;lastState=n;
    const others=[...clients].filter(x=>x!==c&&x.hello&&x.role==='klocka');
    if(others.length&&!limited('dupwrite',30000))add({typ:'avvikelse',niv:'avvikelse',text:'Klockans läge skrivs medan fler än en enhet har Klocka-rollen ('+[c].concat(others).map(x=>x.ip).join(', ')+')',d:{ips:[c].concat(others).map(x=>x.ip)}});
    if(p&&p.v!==n.v)diffState(p,n)}
  /* ---------- händelser från hubben ---------- */
  function hello(c){
    const nm=nameOf(c),others=[...clients].filter(x=>x!==c&&x.hello&&x.role==='klocka');
    add({typ:'anslutning',text:nm+' ansluten ('+c.ip+')',d:{roll:c.role,sida:c.page,lag:c.lag,ip:c.ip,enhet:uaLabel(c.ua),antal:clients.size}});
    if(c.role==='klocka'&&others.length)add({typ:'avvikelse',niv:'avvikelse',text:'Två enheter har Klocka-rollen: '+c.ip+' och '+others.map(x=>x.ip).join(', '),d:{ips:[c.ip].concat(others.map(x=>x.ip))}});
    if(c.role!=='klocka'&&(!c.page||!(c.page in PAGES)))add({typ:'avvikelse',niv:'avvikelse',text:'Okänd sida ansluten: "'+(c.page||'(tom)')+'" från '+c.ip,d:{sida:c.page,ip:c.ip}});
    const key=c.ip+'|'+(c.page||'')+(c.lag||''),n=Date.now(),h=(flap.get(key)||[]).filter(t=>n-t<FLAP_MS);h.push(n);flap.set(key,h);
    if(h.length>=FLAP_N&&!limited('flap'+key,FLAP_MS))add({typ:'avvikelse',niv:'avvikelse',text:'Upprepade återanslutningar: '+nm+' ('+c.ip+') har anslutit '+h.length+' gånger på '+Math.round(FLAP_MS/60000)+' min – instabil kabel/wifi?',d:{ip:c.ip,antal:h.length}})}
  function close(c){const nm=nameOf(c),dur=Date.now()-(c.since||Date.now()),run=c.role==='klocka'&&lastState&&lastState.clock&&lastState.clock.running;
    add({typ:'anslutning',niv:c.role==='klocka'?'avvikelse':'info',text:nm+' frånkopplad ('+c.ip+') efter '+fmtDur(dur)+(run?' – KLOCKAN GICK':''),d:{roll:c.role,ip:c.ip,anslutenMs:dur,klockanGick:!!run,kvar:clients.size}})}
  function tick(){const n=Date.now();clients.forEach(c=>{if(!c.hello)return;const q=n-(c.last||n);
    if(q>GAP_MS&&!c.gap){c.gap=n;add({typ:'synk',niv:'avvikelse',text:'Tappad synk: ingen signal från '+nameOf(c)+' ('+c.ip+') på '+Math.round(q/1000)+' s',d:{ip:c.ip,tystMs:q}})}})}
  function heard(c){if(c.gap){const d=Date.now()-c.gap;c.gap=0;add({typ:'synk',text:nameOf(c)+' ('+c.ip+') åter i kontakt (var tyst ~'+fmtDur(d)+')',d:{ip:c.ip}})}}
  function skew(c,off){c.off=off;if(Math.abs(off)>SKEW_WARN&&!c.skewWarn){c.skewWarn=1;add({typ:'avvikelse',niv:'avvikelse',text:'Stort klockskev: '+nameOf(c)+' ('+c.ip+') går '+fmtDur(Math.abs(off))+(off>0?' efter':' före')+' hubben (kompenseras automatiskt men kolla enhetens tid)',d:{ip:c.ip,offMs:Math.round(off)}})}}
  function resync(c){const key='rs'+c.id;if(limited(key,10000)){c.rsN=(c.rsN||0)+1;return}
    add({typ:'synk',niv:'avvikelse',text:nameOf(c)+' ('+c.ip+') hade ett annat läge än Klocka efter puls – omsynkad'+(c.rsN?' ('+c.rsN+' till nyligen)':''),d:{ip:c.ip}});c.rsN=0}
  function rejected(c,k){if(limited('rej'+c.id,10000))return;
    add({typ:'avvikelse',niv:'avvikelse',text:nameOf(c)+' ('+c.ip+') försökte skriva Klockas läge – avvisat (bara Klocka får)',d:{ip:c.ip,sida:c.page,roll:c.role}})}
  function stale(c,k){if(k!==KLOCKA_KEY||limited('stale'+c.id,10000))return;
    add({typ:'avvikelse',niv:'avvikelse',text:'Konflikt: '+nameOf(c)+' ('+c.ip+') skrev ett äldre Klocka-läge än hubbens – avvisat',d:{ip:c.ip}})}
  function resetSignal(c){add({typ:'nollställning',m:1,text:'"Nollställ allt" skickat från Klocka (alla moduler rensar sina data)',match:lastState?lastState.home+' – '+lastState.away:'',per:lastState?lastState.period:'',kt:lastState?kt(lastState,Date.now()):''})}
  function hubReset(){lastState=null;cond.clear();add({typ:'nollställning',niv:'avvikelse',text:'Hubbens lagrade läge rensades (reset)'})}
  /* ---------- admin-API ---------- */
  function ips(){const r=[];Object.values(os.networkInterfaces()).forEach(a=>(a||[]).forEach(i=>{if(i&&i.family==='IPv4'&&!i.internal)r.push(i.address)}));return r}
  function data(since,bootId,port){const n=Date.now();
    const devs=[...clients].filter(c=>c.hello).map(c=>{const q=n-(c.last||n);return{id:c.id,page:c.page,namn:nameOf(c),roll:c.role,ro:!c.op,ip:c.ip,enhet:uaLabel(c.ua),lag:c.lag||'',sinceMs:n-(c.since||n),lastMs:q,skew:c.off==null?null:Math.round(c.off),status:q<STALE_WARN?'ok':q<STALE_BAD?'varning':'tyst'}});
    const kl=devs.filter(d=>d.roll==='klocka'),st=getKlocka&&getKlocka(),s=lastState;
    const klocka={connected:kl.length>0,antal:kl.length,lastMs:kl.length?Math.min(...kl.map(d=>d.lastMs)):null,stateAgeMs:st&&st.ts?n-st.ts:null,
      match:s?s.home+' – '+s.away:'',period:s?s.period:'',score:s?s.goals.join('–'):'',running:s?!!s.clock.running:null,kt:s?kt(s,n):''};
    const same=bootId===boot;let ev=same?ring.filter(e=>e.id>since):ring.slice(-500);
    return{ok:true,boot,now:n,version:VERSION,uptimeMs:n-boot,hub:{port,ips:ips(),host:os.hostname()},klocka,devices:devs,events:ev,seq,reset:!same||since===0,log:stats(),tz:'Europe/Stockholm'}}
  function readDay(dag){let r=[];try{fs.readFileSync(dayFile(dag),'utf8').split('\n').forEach(l=>{if(l){try{r.push(JSON.parse(l))}catch(e){}}})}catch(e){}return r}
  function exportDay(dag,onlyMatch,fmt){let r=readDay(dag);if(onlyMatch)r=r.filter(e=>e.m);
    if(fmt==='json')return{type:'application/json; charset=utf-8',body:JSON.stringify({dag,events:r})};
    const rows=[CSVH.join(';')].concat(r.map(e=>[e.dag,e.tid,e.typ,e.niv,e.match,e.per,e.kt,e.lag,e.nr,e.straff,e.text].map(csvCell).join(';')));
    return{type:'text/csv; charset=utf-8',body:'\ufeff'+rows.join('\r\n')+'\r\n',name:'matchlogg_'+dag+(onlyMatch?'_matchhandelser':'')+'.csv'}}
  /* ---------- HTTP ---------- */
  function allowed(req){const a=req.socket&&req.socket.remoteAddress;if(!privateIp(a))return false;
    const x=req.headers['x-forwarded-for'];if(x&&!String(x).split(',').every(s=>privateIp(s.trim())))return false;return true}
  /* ---------- PIN (valfri): ADMIN_PIN / adminPin. Tom = ingen PIN, allt som förut ----------
     Skyddat: operatörssidor (Klocka/index, OVR, Speaker, På isen, Skott), adminsidan, samt WebSocket-skrivning
     (Klocka-rollen och alla set-meddelanden). Displaysidor (domare, omklädningsrum, jumbotron, tv/ndi) är öppna och skrivskyddade.
     Cookies är signerade (HMAC, hemlig nyckel i session.secret + PIN) och överlever därför hubbomstart. Ändrad PIN gör alla cookies ogiltiga. */
  const FAILS=new Map(),MAXFAIL=5,FAIL_WIN=60000,OP_MS=30*864e5,ADM_MS=12*36e5;
  const hash=x=>crypto.createHash('sha256').update(String(x)).digest(),PINH=PIN?hash(PIN):null;
  const pinOk=x=>!!PINH&&crypto.timingSafeEqual(PINH,hash(x));
  let KEY=null;
  if(PIN){let sec='';try{sec=fs.readFileSync(o.secretFile,'utf8').trim()}catch(e){}
    if(!/^[0-9a-f]{64}$/.test(sec)){sec=crypto.randomBytes(32).toString('hex');try{fs.writeFileSync(o.secretFile,sec+'\n',{mode:0o600})}catch(e){log('Kunde inte spara '+o.secretFile+' ('+e.message+') – inloggade enheter måste logga in igen efter omstart')}}
    KEY=crypto.createHmac('sha256',sec).update('pin:'+PIN).digest()}
  const sign=x=>crypto.createHmac('sha256',KEY).update(x).digest('hex');
  const mint=(scope,ttl)=>{const p=scope+'.'+(Date.now()+ttl);return p+'.'+sign(p)};
  const COOK={op:'mk_op',adm:'admin_sess'};
  function cookieOk(req,scope){if(!PIN)return true;const m=String(req.headers.cookie||'').match(new RegExp('(?:^|;\\s*)'+COOK[scope]+'=([a-z]+\\.\\d+\\.[0-9a-f]{64})'));if(!m)return false;
    const t=m[1].split('.');if(t[0]!==scope||+t[1]<=Date.now())return false;const e=sign(t[0]+'.'+t[1]);return crypto.timingSafeEqual(Buffer.from(e),Buffer.from(t[2]))}
  const operator=req=>cookieOk(req,'op'),authed=req=>cookieOk(req,'adm');
  const clientIp=req=>String((req.socket&&req.socket.remoteAddress)||'').replace(/^::ffff:/,'');
  function failsOf(ip){const n=Date.now(),a=(FAILS.get(ip)||[]).filter(t=>n-t<FAIL_WIN);if(a.length)FAILS.set(ip,a);else FAILS.delete(ip);return a}
  const sweep=setInterval(()=>{[...FAILS.keys()].forEach(failsOf)},60000);if(sweep.unref)sweep.unref();
  /* Räknar ett felaktigt försök; loggar avvikelse. Returnerar true om IP:n nu är spärrad. */
  function failed(req,what){const ip=clientIp(req),a=failsOf(ip);a.push(Date.now());FAILS.set(ip,a);const locked=a.length>=MAXFAIL;
    add({typ:'avvikelse',niv:'avvikelse',text:'Felaktig PIN ('+what+') från '+ip+' (försök '+a.length+' av '+MAXFAIL+' per minut)'+(locked?' – spärrad i 1 minut':''),d:{ip,försök:a.length,spärrad:locked,enhet:uaLabel(req.headers['user-agent'])}});return locked}
  /* Spärrade IP-adresser (>= MAXFAIL fel inom FAIL_WIN) med kvarvarande tid i sekunder. Spärren släpper när det äldsta av de senaste MAXFAIL felen blir äldre än FAIL_WIN. */
  function locks(){const n=Date.now(),r=[];[...FAILS.keys()].forEach(ip=>{const a=failsOf(ip);if(a.length>=MAXFAIL)r.push({ip,kvarS:Math.max(1,Math.ceil((a[a.length-MAXFAIL]+FAIL_WIN-n)/1000))})});return r.sort((x,y)=>y.kvarS-x.kvarS)}
  const lockedNow=req=>failsOf(clientIp(req)).length>=MAXFAIL;
  const OPPAGES=new Set(['/matchklocka/kontroll.html','/matchklocka/index.html','/matchklocka/','/matchklocka','/matchklocka/ovr.html','/matchklocka/paisen.html','/matchklocka/skott.html','/speaker.html']);
  const isOpPage=P=>{let x;try{x=decodeURIComponent(P)}catch(e){return true}x=path.posix.normalize(x.replace(/\\/g,'/')).toLowerCase();return OPPAGES.has(x)};
  /* Anropas av bridge.js före statiska filer. true = svar skickat (omdirigerat till PIN-sidan). */
  function pageGate(req,res,u){if(!PIN||!isOpPage(u.pathname)||operator(req))return false;
    res.writeHead(302,{Location:'/login?next='+encodeURIComponent(u.pathname+u.search),'Cache-Control':'no-store'});res.end();return true}
  const LOGIN=(msg,act,next,titel)=>'<!doctype html><html lang="sv"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+titel+' – PIN</title><style>body{margin:0;background:#0f1216;color:#e8edf3;font:16px system-ui,Arial,sans-serif;display:flex;min-height:100vh;align-items:center;justify-content:center}form{background:#181d24;border:1px solid #2a323d;border-radius:12px;padding:24px 28px;width:300px}h1{font-size:18px;margin:0 0 4px}p{color:#8b97a6;font-size:13px;margin:0 0 14px}input,button{width:100%;box-sizing:border-box;font:inherit;padding:10px;border-radius:8px;border:1px solid #2a323d;background:#0f1216;color:#e8edf3;margin-bottom:10px}input{text-align:center;letter-spacing:6px;font-size:22px}button{background:#2fb35a;border:0;color:#fff;font-weight:700;cursor:pointer}.e{color:#ff8a8a;font-size:13px;min-height:18px;margin:0 0 8px}</style></head><body><form method="post" action="'+act+'"><h1>'+titel+'</h1><p>Ange PIN-kod för att fortsätta.</p><div class="e">'+(msg||'')+'</div><input type="hidden" name="next" value="'+String(next||'').replace(/[&<>"]/g,'')+'"><input name="pin" type="password" inputmode="numeric" autocomplete="off" autofocus maxlength="64" placeholder="PIN"><button type="submit">Öppna</button></form></body></html>';
  function readBody(req,cb){let b='',done=false;req.on('data',c=>{b+=c;if(b.length>2048&&!done){done=true;req.destroy()}});req.on('end',()=>{if(!done){done=true;cb(b)}});req.on('error',()=>{})}
  const safeNext=n=>/^\/(?!\/)[^\r\n\\]*$/.test(String(n||''))?String(n):'';
  function handle(req,res,u){const P=u.pathname,ADMIN=P==='/admin'||P==='/admin/'||P==='/admin/data'||P==='/admin/export'||P==='/admin/login'||P==='/admin/logout'||P==='/admin/unlock';
    if(!ADMIN&&P!=='/login'&&P!=='/logout')return false;
    const H=(c,t,extra)=>Object.assign({'Content-Type':t,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'},extra||{});
    const html=(code,body,extra)=>{res.writeHead(code,H(code,'text/html; charset=utf-8',extra));res.end(body)};
    const see=(loc,extra)=>{res.writeHead(303,H(303,'text/plain',Object.assign({Location:loc},extra||{})));res.end()};
    /* privata adresser gäller adminsidan; operatörsinloggningen (/login) är öppen för alla som når hubben */
    if(ADMIN&&!allowed(req)){res.writeHead(403,H(403,'text/plain; charset=utf-8'));res.end('Adminsidan är bara tillgänglig från lokalt nätverk/VPN.');return true}
    const scope=ADMIN?'adm':'op',titel=ADMIN?'Admin – Matchklocka':'Matchklocka – operatör',act=ADMIN?'/admin/login':'/login',home=ADMIN?'/admin':'/matchklocka/index.html';
    const ck=(v,age)=>COOK[scope]+'='+v+'; HttpOnly; SameSite=Strict; Path='+(ADMIN?'/admin':'/')+'; Max-Age='+age;
    if(P==='/login'||P==='/admin/login'){
      if(req.method==='GET'&&P==='/login'){if(!PIN||operator(req))see(safeNext(u.searchParams.get('next'))||home);else html(200,LOGIN('',act,safeNext(u.searchParams.get('next')),titel));return true}
      if(req.method!=='POST'||!PIN){see(home);return true}
      readBody(req,body=>{const q=new URLSearchParams(body),next=safeNext(q.get('next'))||home;
        if(lockedNow(req)){const w=Math.max(1,Math.ceil((failsOf(clientIp(req))[0]+FAIL_WIN-Date.now())/1000));html(429,LOGIN('För många felaktiga försök. Vänta '+w+' s och försök igen.',act,next,titel),{'Retry-After':String(w)});return}
        if(pinOk(q.get('pin')||'')){FAILS.delete(clientIp(req));add({typ:'system',text:(ADMIN?'Admin':'Operatör')+' inloggad från '+clientIp(req),d:{ip:clientIp(req),enhet:uaLabel(req.headers['user-agent'])}});see(next,{'Set-Cookie':ck(mint(scope,ADMIN?ADM_MS:OP_MS),(ADMIN?ADM_MS:OP_MS)/1000)});return}
        const lk=failed(req,ADMIN?'admin':'operatör');html(lk?429:401,LOGIN(lk?'För många felaktiga försök. Vänta 60 s och försök igen.':'Fel PIN-kod.',act,next,titel),lk?{'Retry-After':'60'}:{})});
      return true}
    if(P==='/logout'||P==='/admin/logout'){if(req.method!=='POST'){res.writeHead(405,H(405,'text/plain'));res.end('Method not allowed');return true}see(ADMIN?'/admin':'/login',{'Set-Cookie':ck('',0)});return true}
    if(P==='/admin/unlock'){
      if(req.method!=='POST'){res.writeHead(405,H(405,'text/plain'));res.end('Method not allowed');return true}
      if(!authed(req)){res.writeHead(401,H(401,'application/json; charset=utf-8'));res.end('{"fel":"PIN krävs"}');return true}
      readBody(req,body=>{const ip=String(new URLSearchParams(body).get('ip')||'').slice(0,64),who=clientIp(req),all=ip==='alla';
        const targets=all?locks().map(x=>x.ip):(locks().some(x=>x.ip===ip)?[ip]:[]);targets.forEach(t=>FAILS.delete(t));
        if(targets.length)add({typ:'system',text:'PIN-spärr upplåst för '+(all?targets.length+' IP-adress'+(targets.length>1?'er':'')+' ('+targets.join(', ')+')':ip)+' av admin från '+who,d:{ip:who,upplåsta:targets}});
        res.writeHead(200,H(200,'application/json; charset=utf-8'));res.end(JSON.stringify({ok:true,upplåsta:targets.length}))});
      return true}
    if(req.method!=='GET'){res.writeHead(405,H(405,'text/plain'));res.end('Method not allowed');return true}
    if(!authed(req)){
      if(P==='/admin'||P==='/admin/'){html(200,LOGIN('',act,'/admin',titel));return true}
      res.writeHead(401,H(401,'application/json; charset=utf-8'));res.end('{"fel":"PIN krävs"}');return true}
    if(P==='/admin'||P==='/admin/'){res.writeHead(200,H(200,'text/html; charset=utf-8'));res.end(PAGEHTML);return true}
    if(P==='/admin/data'){const d=data(+u.searchParams.get('since')||0,+u.searchParams.get('boot')||0,req.socket.localPort);d.pinOn=!!PIN;d.spar=locks();res.writeHead(200,H(200,'application/json; charset=utf-8'));res.end(JSON.stringify(d));return true}
    const dag=u.searchParams.get('dag')||sthlm(Date.now()).dag;
    if(!/^\d{4}-\d{2}-\d{2}$/.test(dag)){res.writeHead(400,H(400,'text/plain'));res.end('Ogiltigt datum');return true}
    const r=exportDay(dag,u.searchParams.get('match')==='1',u.searchParams.get('format')||'csv');
    res.writeHead(200,H(200,r.type,r.name?{'Content-Disposition':'attachment; filename="'+r.name+'"'}:{}));res.end(r.body);return true}
  /* skrivskyddad WS-klient (ingen operatörscookie) försökte skriva / ta Klocka-rollen */
  function noPin(c,what){if(limited('nopin'+c.id,15000))return;add({typ:'avvikelse',niv:'avvikelse',text:nameOf(c)+' ('+c.ip+') försökte '+what+' utan operatörs-PIN – nekat (skrivskyddad anslutning)',d:{ip:c.ip,sida:c.page,roll:c.role}})}
  /* ---------- start ---------- */
  try{const s=getKlocka&&getKlocka();if(s&&s.v)lastState=JSON.parse(s.v)}catch(e){}
  loadRecent();cleanup();
  const t1=setInterval(cleanup,864e5),t2=setInterval(tick,2000);if(t1.unref)t1.unref();if(t2.unref)t2.unref();
  add({typ:'system',text:'Hubben startad (version '+VERSION+'), loggen sparas '+DAYS+' dagar i '+DIR+(PIN?', PIN krävs för admin och operatörssidor':', ingen PIN'),d:{versionen:VERSION}});
  return{pinOn:!!PIN,operator,pageGate,noPin,add,hello,close,tick,heard,skew,resync,rejected,stale,resetSignal,hubReset,klockaState,handle,allowed,data,exportDay,cleanup,stats,privateIp,nameOf,PAGES};
};
module.exports.privateIp=privateIp;
