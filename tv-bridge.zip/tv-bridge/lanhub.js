/* LAN-synkhubb (del av bridge.js, inga beroenden). Håller senaste värdet per delad nyckel (localStorage-nycklar från sidorna),
   relä:ar ändringar mellan enheter över WebSocket (/lan), ger sena anslutare hela läget (/lan/snapshot + hello) och serverns tid.
   Konflikter: senaste tidsstämpel vinner; matchklocka_state_v1 får bara skrivas av klienter med role=klocka. */
'use strict';
const fs=require('fs'),path=require('path');
const KLOCKA_KEY='matchklocka_state_v1';
/* Samma lista som i matchklocka/lansync.js */
const SYNC=k=>typeof k==='string'&&k.length<200&&(k===KLOCKA_KEY||k==='paisen_v1'||k==='paisen_override'||k==='skott_v1'||/^speakerapp_(protokoll|override|lineup)_/.test(k)||k==='matchklocka_reset_v1'||/^matchklocka_nrfix_v1_/.test(k)||/^publik_/.test(k));
module.exports=function create(o){
  const log=o.log,send=o.send,FILE=o.file,VERSION=o.version;
  const clients=new Set();let store={},saveT=null,fresh=!!o.fresh;
  if(!fresh){try{const j=JSON.parse(fs.readFileSync(FILE,'utf8'));if(j&&j.items&&typeof j.items==='object'){store=j.items;log('LAN-hubb: laddade '+Object.keys(store).length+' nycklar från '+path.basename(FILE)+' (starta med --fresh för tomt läge)')}}catch(e){}}
  else log('LAN-hubb: startar med tomt läge (--fresh)');
  const save=()=>{clearTimeout(saveT);saveT=setTimeout(()=>{try{fs.writeFileSync(FILE+'.tmp',JSON.stringify({saved:Date.now(),items:store}));fs.renameSync(FILE+'.tmp',FILE)}catch(e){log('LAN-hubb: kunde inte spara '+path.basename(FILE)+': '+e.message)}},800)};
  const peersMsg=()=>({t:'peers',n:clients.size,list:[...clients].map(c=>({role:c.role,page:c.page,ip:c.ip}))});
  const bcast=(m,except)=>clients.forEach(c=>{if(c!==except&&c.hello)send(c,m)});
  /* Försök skriva; returnerar true om nyckeln ändrades */
  function put(c,k,v,ts){if(!SYNC(k))return false;ts=+ts||0;const n=Date.now();if(ts>n+5000)ts=n;
    if(v!=null&&typeof v!=='string')return false;
    if(k===KLOCKA_KEY&&c.role!=='klocka'){const cur=store[k];if(cur)send(c,{t:'set',k,v:cur.v,ts:cur.ts});return false}
    const cur=store[k];if(cur&&ts<cur.ts){send(c,{t:'set',k,v:cur.v,ts:cur.ts});return false}
    if(cur&&cur.ts===ts&&cur.v===v)return false;
    store[k]={v:v==null?null:v,ts,by:c.id};save();return true}
  return{
    clients,
    open(c,req){c.ip=String((req&&req.socket&&req.socket.remoteAddress)||'').replace('::ffff:','');c.role='klient';c.page='';c.hello=false;clients.add(c)},
    msg(c,t){let m;try{m=JSON.parse(t)}catch(e){return}
      if(m.t==='hello'){c.role=m.role==='klocka'?'klocka':'klient';c.page=String(m.page||'').slice(0,40);c.id=String(m.id||'').slice(0,12);
        const ch=[];for(const k in (m.items||{})){const it=m.items[k];if(it&&put(c,k,it.v,it.ts))ch.push(k)}
        c.hello=true;
        send(c,{t:'snapshot',version:VERSION,time:Date.now(),items:store});
        ch.forEach(k=>bcast({t:'set',k,v:store[k].v,ts:store[k].ts},c));
        log('LAN: '+(c.role==='klocka'?'Klocka':c.page||'enhet')+' ansluten från '+c.ip+' ('+clients.size+' enheter'+(ch.length?', '+ch.length+' nycklar uppdaterade från den':'')+')');
        bcast(peersMsg())}
      else if(m.t==='set'){if(put(c,m.k,m.v,m.ts)){bcast({t:'set',k:m.k,v:store[m.k].v,ts:store[m.k].ts},c);if(o.verbose())log('LAN set '+m.k+' ('+(m.v==null?0:m.v.length)+' tecken) från '+(c.page||c.ip))}}
      else if(m.t==='ping')send(c,{t:'pong',c:m.c,s:Date.now()})},
    close(c){if(clients.delete(c)&&c.hello){log('LAN: '+(c.role==='klocka'?'Klocka':c.page||'enhet')+' frånkopplad ('+c.ip+') – '+clients.size+' kvar');bcast(peersMsg())}},
    snapshot(){return{hub:true,version:VERSION,time:Date.now(),items:store}},
    status(){return{hub:true,version:VERSION,time:Date.now(),klienter:[...clients].map(c=>({role:c.role,page:c.page,ip:c.ip})),nycklar:Object.keys(store).map(k=>({k,ts:store[k].ts,bytes:store[k].v==null?0:store[k].v.length}))}},
    reset(){store={};save();clients.forEach(c=>send(c,{t:'snapshot',version:VERSION,time:Date.now(),items:{}}))}
  };
};
