/* LAN-synkhubb (del av bridge.js, inga beroenden). Håller senaste värdet per delad nyckel (localStorage-nycklar från sidorna),
   relä:ar ändringar mellan enheter över WebSocket (/lan), ger sena anslutare hela läget (/lan/snapshot + hello) och serverns tid.
   Konflikter: senaste tidsstämpel vinner; matchklocka_state_v1 får bara skrivas av klienter med role=klocka.
   En-instans-spärr: Klocka, Speaker, Skott/innehav och På isen (hemma/borta var för sig) får bara vara öppna på EN enhet åt gången (se SLOTS nedan). OVR och visningsskärmar är obegränsade. */
'use strict';
const fs=require('fs'),path=require('path');
const createAdmin=require('./lanadmin.js');
const KLOCKA_KEY='matchklocka_state_v1';
/* Samma lista som i matchklocka/lansync.js */
const SYNC=k=>typeof k==='string'&&k.length<200&&(k===KLOCKA_KEY||k==='paisen_v1'||k==='paisen_override'||k==='skott_v1'||k==='zon_v1'||/^speakerapp_(protokoll|override|lineup)_/.test(k)||k==='matchklocka_reset_v1'||/^matchklocka_nrfix_v1_/.test(k)||/^publik_/.test(k));
module.exports=function create(o){
  const log=o.log,send=o.send,FILE=o.file,VERSION=o.version;
  const clients=new Set();let store={},saveT=null,fresh=!!o.fresh;
  /* Admin/logg: fel här får aldrig påverka synken */
  let ADM=null;const A=(f,...a)=>{try{if(ADM)return ADM[f](...a)}catch(e){log('Admin-logg: '+e.message)}};
  if(!fresh){try{const j=JSON.parse(fs.readFileSync(FILE,'utf8'));if(j&&j.items&&typeof j.items==='object'){store=j.items;log('LAN-hubb: laddade '+Object.keys(store).length+' nycklar från '+path.basename(FILE)+' (starta med --fresh för tomt läge)')}}catch(e){}}
  else log('LAN-hubb: startar med tomt läge (--fresh)');
  try{ADM=createAdmin({log,clients,version:VERSION,dir:o.logDir,days:o.logDays,maxMB:o.logMaxMB,pin:o.adminPin,secretFile:o.secretFile,getKlocka:()=>store[KLOCKA_KEY],slots:()=>SL.list(),release:(slot,who)=>SL.release(slot,who)})}catch(e){log('Admin-logg kunde inte startas: '+e.message)}
  const save=()=>{clearTimeout(saveT);saveT=setTimeout(()=>{try{fs.writeFileSync(FILE+'.tmp',JSON.stringify({saved:Date.now(),items:store}));fs.renameSync(FILE+'.tmp',FILE)}catch(e){log('LAN-hubb: kunde inte spara '+path.basename(FILE)+': '+e.message)}},800)};
  const live=()=>[...clients].filter(c=>!c.blocked);
  const peersMsg=()=>{const L=live();return{t:'peers',n:L.length,list:L.map(c=>({role:c.role,page:c.page,ip:c.ip}))}};
  const bcast=(m,except)=>clients.forEach(c=>{if(c!==except&&c.hello)send(c,m)});
  /* Försök skriva; returnerar true om nyckeln ändrades */
  function put(c,k,v,ts){if(!SYNC(k))return false;if(c.blocked){const cu=store[k];if(cu)send(c,{t:'set',k,v:cu.v,ts:cu.ts});return false}ts=+ts||0;const n=Date.now();if(ts>n+5000)ts=n;
    if(v!=null&&typeof v!=='string')return false;
    if(k===KLOCKA_KEY&&c.role!=='klocka'){const cur=store[k];if(cur)send(c,{t:'set',k,v:cur.v,ts:cur.ts});A('rejected',c,k);return false}
    const cur=store[k];if(cur&&ts<cur.ts){send(c,{t:'set',k,v:cur.v,ts:cur.ts});A('stale',c,k);return false}
    if(cur&&cur.ts===ts&&cur.v===v)return false;
    store[k]={v:v==null?null:v,ts,by:c.id};save();
    if(k===KLOCKA_KEY&&v!=null)A('klockaState',c,store[k]);else if(k==='matchklocka_reset_v1'&&v!=null)A('resetSignal',c);
    return true}
  /* Puls: varje sekund får alla anslutna enheter {t:'hb'} (hubbens tid + Klockas fulla läge, serialiserat en gång). Klockan själv får bara tiden – Klocka är enda källan och skrivs aldrig över. Klienter räknar tid sedan senaste meddelande och visar 'frånkopplad' vid tystnad. */
  const HB_MS=1000;
  const hbT=setInterval(()=>{if(!clients.size)return;const k=store[KLOCKA_KEY],t=Date.now(),full={t:'hb',time:t,k:k&&k.v!=null?{v:k.v,ts:k.ts}:null},lite={t:'hb',time:t};
    clients.forEach(c=>{if(c.hello)send(c,c.role==='klocka'&&!c.blocked?lite:full)})},HB_MS);if(hbT.unref)hbT.unref();

  /* ---------- En-instans-spärr (platser/slots) ----------
     Bara EN enhet åt gången får ha: Klocka ('klocka'), Speaker ('speaker'), Skott/innehav ('skott') och På isen per lag ('paisen:hemma', 'paisen:borta'; utan ?lag= egen plats 'paisen:').
     Obegränsat: OVR Rapport, visningsskärmar (jumbotron, domare, omklädningsrum, TV/NDI), KommentatorApp, Speaker U18 och fristående Speaker-filer.
     Enheter utan operatörs-PIN (skrivskyddade) tar aldrig någon plats. Ägaren identifieras med webbläsarflikens id (cid, sessionStorage) – samma flik som laddas om tar tillbaka sin plats direkt.
     Plats frigörs: ägaren kopplar ner, ägaren varit tyst > SILENT_MS (klienter pingar var 4:e s), eller admin trycker Släpp.
     Nekad klient markeras c.blocked: den får läsa (snapshot/puls) men inte skriva, och visar en heltäckande ruta ({t:'busy'}); den försöker igen automatiskt ({t:'ledig'} skickas direkt när platsen frigörs). */
  const SILENT_MS=10000,REFUSE_LOG_MS=60000;
  const SLOTNAME={klocka:'Klocka',speaker:'Speaker',skott:'Skott & puckinnehav','paisen:hemma':'På isen – hemma','paisen:borta':'På isen – borta'};
  const slotName=s=>SLOTNAME[s]||(/^paisen:/.test(s)?'På isen'+(s.slice(7)?' ('+s.slice(7)+')':' (utan lag)'):s);
  const slotOf=c=>{if(!c.op)return '';if(c.role==='klocka'||c.page==='kontroll')return 'klocka';if(c.page==='speaker')return 'speaker';if(c.page==='skott')return 'skott';if(c.page==='paisen')return 'paisen:'+(c.lag||'');return ''};
  const slots=new Map(),refLog=new Map();
  const uaL=c=>{try{return ADM&&ADM.uaLabel?ADM.uaLabel(c.ua):''}catch(e){return ''}};
  const slog=(niv,text,d)=>A('add',{typ:'spärr',niv,text,d});
  const who=c=>(uaL(c)||'enhet')+' '+c.ip;
  function holder(slot){const o=slots.get(slot);if(!o)return null;if(!clients.has(o)||(o.sock&&o.sock.destroyed)){slots.delete(slot);return null}return o}
  function busyMsg(c){const b=c.blocked||{},o=holder(b.slot);return{t:'busy',slot:b.slot,namn:slotName(b.slot),orsak:b.reason,manuell:!!b.manuell,enhet:o?uaL(o):'',ip:o?o.ip:'',sedan:o?o.slotSince:null,nu:Date.now()}}
  function notifyFree(slot){clients.forEach(c=>{if(c.blocked&&c.blocked.slot===slot&&!c.blocked.manuell&&c.blocked.reason!=='tyst')send(c,{t:'ledig',slot})})}
  function demote(o,reason,manuell){o.blocked={slot:o.slot,reason,since:Date.now(),manuell:!!manuell};if(slots.get(o.slot)===o)slots.delete(o.slot)}
  /* Försöker ge c sin plats. Returnerar null = c fick den, annars den enhet som håller den. */
  function claim(c,slot){const o=holder(slot);
    if(!o||o===c){slots.set(slot,c);if(!c.slotSince)c.slotSince=Date.now();return null}
    const n=Date.now();
    if(n-(o.last||n)>SILENT_MS){const q=Math.round((n-o.last)/1000);demote(o,'tyst');slots.set(slot,c);c.slotSince=n;send(o,busyMsg(o));slog('info',slotName(slot)+': platsen frigjord – '+who(o)+' har varit tyst i '+q+' s; '+who(c)+' tar över',{slot,fran:o.ip,till:c.ip,tystS:q});return null}
    if(c.cid&&c.cid===o.cid){demote(o,'overtagen');slots.set(slot,c);c.slotSince=o.slotSince||n;send(o,busyMsg(o));slog('info',slotName(slot)+': samma flik anslöt igen ('+who(c)+') – tog tillbaka sin plats (omladdning)',{slot,ip:c.ip});return null}
    return o}
  function refuse(c,slot,o){
    if(!c.blocked)c.blocked={slot,reason:'upptagen',since:Date.now()};c.blocked.slot=slot;send(c,busyMsg(c));
    const k=c.ip+'|'+slot,n=Date.now();if(n-(refLog.get(k)||0)<REFUSE_LOG_MS)return;refLog.set(k,n);
    slog('avvikelse',slotName(slot)+' är redan öppen på '+who(o)+' – '+who(c)+' nekades (visar spärrruta, försöker igen automatiskt)',{slot,nekad:c.ip,nekadEnhet:uaL(c),hallsAv:o.ip,hallsAvEnhet:uaL(o)})}
  const SL={
    list(){const n=Date.now(),all=new Set(['klocka','speaker','skott','paisen:hemma','paisen:borta']);slots.forEach((c,k)=>all.add(k));clients.forEach(c=>{if(c.blocked)all.add(c.blocked.slot)});
      return [...all].map(k=>{const o=holder(k);return{slot:k,namn:slotName(k),hallsAv:o?{enhet:uaL(o),ip:o.ip,page:o.page,sedanMs:n-(o.slotSince||n),lastMs:n-(o.last||n)}:null,vantar:[...clients].filter(c=>c.blocked&&c.blocked.slot===k).map(c=>({enhet:uaL(c),ip:c.ip,manuell:!!c.blocked.manuell}))}})},
    release(slot,by){const o=holder(slot);if(!o)return false;demote(o,'slappt',true);send(o,busyMsg(o));
      slog('info',slotName(slot)+': platsen släppt av '+(by||'admin')+' – '+who(o)+' fick spärrruta',{slot,agare:o.ip});notifyFree(slot);return true},
    /* anropas var 2:a sekund: frigör platser vars ägare tystnat */
    tick(){const n=Date.now();slots.forEach((o,k)=>{if(holder(k)===o&&n-(o.last||n)>SILENT_MS&&[...clients].some(c=>c.blocked&&c.blocked.slot===k)){const q=Math.round((n-o.last)/1000);demote(o,'tyst');slog('info',slotName(k)+': platsen frigjord automatiskt – '+who(o)+' har varit tyst i '+q+' s',{slot:k,agare:o.ip,tystS:q});send(o,busyMsg(o));notifyFree(k)}})},
    dropped(c){const k=c.slot;if(k&&slots.get(k)===c){slots.delete(k);slog('info',slotName(k)+': platsen frigjord – '+who(c)+' kopplade från',{slot:k,agare:c.ip});notifyFree(k)}}
  };
  const slT=setInterval(()=>{try{SL.tick()}catch(e){log('Spärr: '+e.message)}},2000);if(slT.unref)slT.unref();
  return{
    clients,get admin(){return ADM},
    open(c,req){c.ip=String((req&&req.socket&&req.socket.remoteAddress)||'').replace('::ffff:','');c.role='klient';c.op=!ADM||ADM.operator(req);c.page='';c.hello=false;c.since=c.last=Date.now();c.ua=String((req&&req.headers&&req.headers['user-agent'])||'').slice(0,200);clients.add(c)},
    msg(c,t){let m;try{m=JSON.parse(t)}catch(e){return}
      c.last=Date.now();if(c.gap)A('heard',c);
      /* Spärrad klient (nekad, släppt eller frigjord för tystnad): får bara hälsa/pinga. Tystnad-frigjord ägare som hör av sig medan platsen är ledig tar tillbaka den tyst. */
      if(c.blocked&&m.t!=='hello'&&m.t!=='ping'){
        if(m.t==='set')put(c,m.k,m.v,m.ts);
        return}
      if(c.blocked&&m.t==='ping'&&c.blocked.reason==='tyst'&&c.slot&&!holder(c.slot)&&c.op){slots.set(c.slot,c);c.slotSince=Date.now();c.blocked=null;send(c,{t:'ok',slot:c.slot,reload:false});slog('info',slotName(c.slot)+': '+who(c)+' hörde av sig igen och tog tillbaka platsen (ingen annan hade tagit den)',{slot:c.slot,ip:c.ip})}
      if(c.blocked&&m.t==='ping'&&Date.now()-(c.busyAt||0)>3000){c.busyAt=Date.now();send(c,busyMsg(c))}
      if(m.t==='hello'){
        if(c.hello&&!c.blocked)return; /* redan ansluten och godkänd – ignorera dubbel hälsning */
        const again=!!c.hello; /* spärrad klient som försöker igen */
        c.role=m.role==='klocka'?'klocka':'klient';if(!c.op&&c.role==='klocka'){c.role='klient';ADM.noPin(c,'ansluta som Klocka')}c.page=String(m.page||'').slice(0,40);c.lag=String(m.lag||'').replace(/[^\wåäöÅÄÖ-]/g,'').slice(0,12);c.id=String(m.id||'').slice(0,12);c.cid=String(m.cid||'').replace(/[^\w-]/g,'').slice(0,20);
        const slot=slotOf(c);let busy=null;
        if(slot){c.slot=slot;busy=claim(c,slot)}else c.slot='';
        if(busy){refuse(c,slot,busy);
          if(!again){c.hello=true;send(c,{t:'snapshot',version:VERSION,time:Date.now(),items:store})} /* får läsa, inte skriva */
          return}
        const wasWaiting=c.blocked;c.blocked=null;if(wasWaiting){send(c,{t:'ok',slot,reload:wasWaiting.reason==='upptagen'});slog('info',slotName(slot)+': '+who(c)+' fick platsen efter att ha väntat',{slot,ip:c.ip})}
        const ch=[];if(!c.op){if(m.items&&Object.keys(m.items).length)ADM.noPin(c,'skriva data')}else for(const k in (m.items||{})){const it=m.items[k];if(it&&put(c,k,it.v,it.ts))ch.push(k)}
        c.hello=true;
        send(c,{t:'snapshot',version:VERSION,time:Date.now(),items:store});
        ch.forEach(k=>bcast({t:'set',k,v:store[k].v,ts:store[k].ts},c));
        log('LAN: '+(c.role==='klocka'?'Klocka':c.page||'enhet')+' ansluten från '+c.ip+' ('+live().length+' enheter'+(ch.length?', '+ch.length+' nycklar uppdaterade från den':'')+')');
        A('hello',c);
        bcast(peersMsg())}
      else if(m.t==='set'){if(!c.op){ADM.noPin(c,'skriva '+String(m.k).slice(0,40));return}if(put(c,m.k,m.v,m.ts)){bcast({t:'set',k:m.k,v:store[m.k].v,ts:store[m.k].ts},c);if(o.verbose())log('LAN set '+m.k+' ('+(m.v==null?0:m.v.length)+' tecken) från '+(c.page||c.ip))}}
      else if(m.t==='ping'){send(c,{t:'pong',c:m.c,s:Date.now()});if(typeof m.off==='number'&&isFinite(m.off))A('skew',c,m.off)}
      else if(m.t==='resync'&&c.hello)A('resync',c)},
    close(c){if(clients.delete(c)&&c.hello){SL.dropped(c);if(c.blocked)return;A('close',c);log('LAN: '+(c.role==='klocka'?'Klocka':c.page||'enhet')+' frånkopplad ('+c.ip+') – '+live().length+' kvar');bcast(peersMsg())}},
    snapshot(){return{hub:true,version:VERSION,time:Date.now(),items:store}},
    status(){return{hub:true,version:VERSION,time:Date.now(),klienter:[...clients].map(c=>({role:c.role,page:c.page,ip:c.ip,spar:c.blocked?c.blocked.slot:undefined})),nycklar:Object.keys(store).map(k=>({k,ts:store[k].ts,bytes:store[k].v==null?0:store[k].v.length}))}},
    /* Senaste Klocka-läge (matchklocka_state_v1) – används av NDI Jumbotron-keeper i bridge.js */
    getKlocka(){return store[KLOCKA_KEY]||null},
    reset(){store={};save();A('hubReset');clients.forEach(c=>send(c,{t:'snapshot',version:VERSION,time:Date.now(),items:{}}))}
  };
};
