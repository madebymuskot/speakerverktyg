/* Startsida för LAN-hubben (/start) + QR-koder (del av bridge.js, inga beroenden).
   Visar adresserna andra enheter ska använda (IP och Mac-namn.local), med QR-kod, samt alla sidor med kopiera-/QR-knapp.
   Öppnas automatiskt på Macen när hubben startas via Starta-Hubben.command. Innehåller inga hemligheter (PIN-koden visas aldrig, bara om en PIN är satt). */
'use strict';
const QR=require('./qrcodegen.js');
const esc=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
function qr(text){return QR.QrCode.encodeText(text,QR.QrCode.Ecc.MEDIUM)}
/* QR som SVG (svart på vitt, 4 moduler tyst zon). */
function qrSvg(text,px){const c=qr(text),n=c.size,b=4;let d='';
  for(let y=0;y<n;y++)for(let x=0;x<n;x++)if(c.getModule(x,y))d+='M'+(x+b)+','+(y+b)+'h1v1h-1z';
  return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 '+(n+2*b)+' '+(n+2*b)+'" width="'+(px||200)+'" height="'+(px||200)+'" shape-rendering="crispEdges" role="img" aria-label="QR-kod"><rect width="100%" height="100%" fill="#fff"/><path d="'+d+'" fill="#000"/></svg>'}
/* Sidor: [namn, sökväg, operatör (PIN om satt), anm] */
const PAGES=[
 ['Startsida (alla sidor)','/',0,''],
 ['Klocka (EN enhet)','/matchklocka/kontroll.html',1,'bara en enhet ska styra klockan'],
 ['Speaker','/speaker.html',1,''],
 ['På isen – hemma (platta)','/matchklocka/paisen.html?lag=hemma',1,''],
 ['På isen – borta (platta)','/matchklocka/paisen.html?lag=borta',1,''],
 ['OVR Rapport','/matchklocka/ovr.html',1,''],
 ['Skott & puckinnehav','/matchklocka/skott.html',1,''],
 ['Jumbotron','/matchklocka/jumbotron.html',0,'visningsskärm'],
 ['Domarskärm','/matchklocka/domare.html',0,'visningsskärm'],
 ['Omklädningsrum','/matchklocka/omkladningsrum.html',0,'visningsskärm'],
 ['Admin & logg','/admin',1,'status, enheter, logg'],
];
function page(o){
  const P=o.port,ips=o.ips||[],hn=o.hostname||'',pin=!!o.pin,ver=o.version||'';
  const bases=ips.map(i=>'http://'+i+':'+P);
  if(hn)bases.push('http://'+hn+'.local:'+P);
  const main=bases[0]||('http://localhost:'+P);
  let h='<!doctype html><html lang="sv"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Matchklocka-hubben</title>'+
  '<style>*{box-sizing:border-box}body{margin:0;background:#0b0b0b;color:#fff;font:16px/1.4 -apple-system,Segoe UI,Roboto,sans-serif}header{background:#AF2E32;padding:16px 22px}h1{margin:0;font-size:26px}header small{opacity:.85}'+
  'main{max-width:1000px;margin:0 auto;padding:18px}h2{color:#AF2E32;font-size:14px;letter-spacing:2px;text-transform:uppercase;margin:26px 0 8px}'+
  '.ok{display:inline-block;width:12px;height:12px;border-radius:50%;background:#2ecc71;margin-right:8px;vertical-align:middle}.bad{background:#e74c3c}'+
  '.cards{display:flex;flex-wrap:wrap;gap:16px}.card{background:#151515;border-left:6px solid #AF2E32;border-radius:10px;padding:16px 18px;display:flex;gap:18px;align-items:center;flex:1 1 420px}'+
  '.card .u{font:800 24px/1.2 ui-monospace,Menlo,Consolas,monospace;word-break:break-all}.card small{color:#bbb;display:block;margin-top:6px}.card svg{flex:none;border-radius:6px}'+
  'table{width:100%;border-collapse:collapse}td{padding:9px 8px;border-bottom:1px solid #222;vertical-align:middle}td.n{font-weight:700;font-size:17px}td small{color:#aaa;font-weight:400}'+
  'a.b,button{background:#222;color:#fff;border:1px solid #444;border-radius:8px;padding:7px 12px;font:600 14px inherit;font-family:inherit;text-decoration:none;cursor:pointer;margin-right:6px;display:inline-block}a.b:hover,button:hover{background:#333}'+
  '.pin{background:#FFB000;color:#000;border-radius:5px;padding:1px 6px;font-size:11px;font-weight:800;margin-left:6px}.qrbox{display:none;padding:10px 0}.qrbox.on{display:block}'+
  '.tips{background:#151515;border-radius:10px;padding:6px 20px;color:#ddd}.tips li{margin:8px 0}code{background:#222;padding:1px 6px;border-radius:4px}</style></head><body>'+
  '<header><h1><span class="ok" id="dot"></span>Matchklocka-hubben körs</h1><small>Version '+esc(ver)+' · port '+P+' · <span id="cnt">…</span></small></header><main>';
  if(!bases.length)h+='<h2>Inget nätverk hittades</h2><div class="tips"><p>Datorn verkar inte vara ansluten till något nätverk. Koppla in nätverkskabel / anslut till Wi-Fi/routern och starta hubben igen. Under tiden fungerar sidorna bara på den här datorn: <code>http://localhost:'+P+'/</code></p></div>';
  else{
    h+='<h2>Öppna på iPad, mobil och andra datorer (samma nätverk)</h2><div class="cards">';
    bases.forEach((b,i)=>{const isName=/\.local:/.test(b);
      h+='<div class="card"><div>'+qrSvg(b+'/',170).replace('<svg','<svg style="display:block"')+'</div><div><div class="u">'+esc(b)+'/</div><small>'+(isName?'Datornamnet (Bonjour) – fungerar på Mac, iPad, iPhone och Windows 10+, inte alla Android. Skriv IP-adressen där.':(i===0?'Skriv in adressen eller skanna QR-koden med kameran.':'Annan nätverksadress (t.ex. kabel och Wi-Fi samtidigt) – använd den som enheten kan nå.'))+'</small></div></div>'});
    h+='</div>';
    h+='<h2>Sidor</h2><table>';
    PAGES.forEach((p,i)=>{const full=main+p[1],id='q'+i;
      h+='<tr><td class="n">'+esc(p[0])+(p[2]&&pin?'<span class="pin">PIN</span>':'')+(p[3]?'<br><small>'+esc(p[3])+'</small>':'')+'<div class="qrbox" id="'+id+'">'+qrSvg(full,170)+'<br><small>'+esc(full)+'</small></div></td>'+
        '<td style="text-align:right;white-space:nowrap"><a class="b" href="'+esc(p[1])+'" target="_blank" rel="noopener">Öppna här</a><button data-c="'+esc(full)+'">Kopiera adress</button><button data-q="'+id+'">QR</button></td></tr>'});
    h+='</table>';
  }
  h+='<h2>Bra att veta</h2><div class="tips"><ul>'+
   '<li>Öppna alltid sidorna <b>från hubben</b> (adresserna ovan) – inte från github.io. Då synkas alla enheter automatiskt, utan internet.</li>'+
   '<li>Alla enheter ska sitta på <b>samma nätverk</b> (inte gästnätverk med klientisolering). Första gången frågar macOS om inkommande anslutningar – svara <b>Tillåt</b>.</li>'+
   '<li>'+(pin?'Operatörssidor (märkta PIN) och Admin kräver PIN-kod första gången på varje enhet; visningsskärmar är öppna.':'Ingen PIN-kod är satt – alla på nätverket kan styra. Sätt <code>adminPin</code> i config.json för att låsa operatörssidorna.')+'</li>'+
   '<li>Låt datorn vara på, med nätadapter, och lämna hubbens Terminal-fönster öppet under matchen. Du kan stänga den här fliken.</li>'+
   '<li>Ger datorn fast IP (DHCP-reservation i routern) blir adresserna likadana varje gång.</li></ul></div></main>'+
  '<script>document.addEventListener("click",function(e){var t=e.target;if(t.dataset.c){var v=t.dataset.c,done=function(){var o=t.textContent;t.textContent="Kopierad ✓";setTimeout(function(){t.textContent=o},1200)};'+
  'if(navigator.clipboard&&window.isSecureContext)navigator.clipboard.writeText(v).then(done,function(){prompt("Kopiera adressen:",v)});else{var a=document.createElement("textarea");a.value=v;document.body.appendChild(a);a.select();try{document.execCommand("copy");done()}catch(x){prompt("Kopiera adressen:",v)}a.remove()}}'+
  'if(t.dataset.q)document.getElementById(t.dataset.q).classList.toggle("on")});'+
  'function st(){fetch("/status",{cache:"no-store"}).then(function(r){return r.json()}).then(function(j){document.getElementById("dot").className="ok";document.getElementById("cnt").textContent=(j.lanEnheter||0)+" enheter synkade"+(j.klockor?" · "+j.klockor+" TV-klocka":"")}).catch(function(){document.getElementById("dot").className="ok bad";document.getElementById("cnt").textContent="ingen kontakt med hubben"})}st();setInterval(st,3000);</script></body></html>';
  return h}
module.exports={page,qrSvg};
