/* Skärmmeny för LAN-hubben (/screens/) + rena skärmadresser och omdirigering från gamla sökvägar.
   Adresserna byggs med hubbens faktiska LAN-IP och port (inga hårdkodade IP).
   Menyn låses med samma operatörs-PIN som modulerna; själva visningsskärmarna är öppna.
   Menyn länkas inte från startsidan eller modulerna. /start omdirigerar till modulmenyn /. */
'use strict';
const fs=require('fs'),path=require('path');
const QR=require('./qrcodegen.js');
const esc=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
function qr(text){return QR.QrCode.encodeText(text,QR.QrCode.Ecc.MEDIUM)}
function qrSvg(text,px){const c=qr(text),n=c.size,b=4;let d='';
  for(let y=0;y<n;y++)for(let x=0;x<n;x++)if(c.getModule(x,y))d+='M'+(x+b)+','+(y+b)+'h1v1h-1z';
  return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 '+(n+2*b)+' '+(n+2*b)+'" width="'+(px||200)+'" height="'+(px||200)+'" shape-rendering="crispEdges" role="img" aria-label="QR-kod"><rect width="100%" height="100%" fill="#fff"/><path d="'+d+'" fill="#000"/></svg>'}

/* group: arena (vanliga visningsskärmar), vilande (dolda/TV), ovrigt (gamla layoutförslag) */
const SCREENS=[
  {id:'jumbotron',name:'Jumbotron',file:'/matchklocka/jumbotron.html',note:'Fullskärm – klicka för helskärm',group:'arena'},
  {id:'jumbotron',name:'Jumbotron (NDI)',file:'/matchklocka/jumbotron.html',query:'ndi=1&bg=black',note:'Ingen muspekare, ingen versionsbar. Byt bg vid behov.',group:'arena',variant:true},
  {id:'domare',name:'Domare',file:'/matchklocka/domare.html',note:'Aktuell avblåsning: mål, assist och utvisningar',group:'arena'},
  {id:'bas-hemma',name:'Utvisning (hemma)',file:'/matchklocka/bas.html',query:'lag=hemma',requireFile:'matchklocka/bas.html',note:'Utvisningstid för hemmalagets bås',group:'arena'},
  {id:'bas-borta',name:'Utvisning (borta)',file:'/matchklocka/bas.html',query:'lag=borta',requireFile:'matchklocka/bas.html',note:'Utvisningstid för bortalagets bås',group:'arena'},
  {id:'omkladningsrum',name:'Omklädningsrum',file:'/matchklocka/omkladningsrum.html',note:'Klocka, period, ställning och nedräkning till start/paus',group:'arena'},
  {id:'tv',name:'TV – transparent',file:'/matchklocka/tv.html',query:'bg=transparent',note:'Browser source i OBS/vMix (1920×1080)',group:'vilande'},
  {id:'tv',name:'TV – grön bakgrund',file:'/matchklocka/tv.html',query:'bg=green',note:'Chroma key',group:'vilande',variant:true},
  {id:'ndi-scorebug',name:'NDI Scorebug',file:'/matchklocka/ndi-scorebug.html',note:'Klocka, ställning, period, utvisningar. ?pos=tl|tr|bl|br|tc|bc',group:'vilande'},
  {id:'ndi-mal',name:'NDI Målgrafik',file:'/matchklocka/ndi-mal.html',note:'Visas när Klocka registrerar mål. ?dur=8 ?pos=top|mid',group:'vilande'},
  {id:'ndi-utvisning',name:'NDI Utvisningsgrafik',file:'/matchklocka/ndi-utvisning.html',note:'Visas vid ny utvisning från Klocka. ?dur=8 ?pos=r',group:'vilande'},
  {id:'jumbotron-gammal',name:'Jumbotron (gammal layout)',file:'/matchklocka/jumbotron-gammal.html',note:'Tidigare layout, behållen som reserv',group:'ovrigt'},
  {id:'jumbotron-forslag',name:'Jumbotron (förslag)',file:'/matchklocka/jumbotron-forslag.html',note:'Förslagslayout',group:'ovrigt'}
];

/* Extra rena alias som omdirigerar till samma skärm med rätt parameter. */
const ALIAS={
  'jumbotron-ndi':{id:'jumbotron',query:'ndi=1&bg=black'},
  'tv-gron':{id:'tv',query:'bg=green'},
  'tv-transparent':{id:'tv',query:'bg=transparent'}
};

/* Bara 'arena' visas i menyn. Vilande TV/NDI och äldre layouter finns kvar som adresser, men listas inte. */
const GROUPS=[
  {id:'arena',title:'Visningsskärmar'}
];

const OLD_FILE={
  '/matchklocka/jumbotron.html':'jumbotron',
  '/matchklocka/domare.html':'domare',
  '/matchklocka/omkladningsrum.html':'omkladningsrum',
  '/matchklocka/tv.html':'tv',
  '/matchklocka/ndi-scorebug.html':'ndi-scorebug',
  '/matchklocka/ndi-mal.html':'ndi-mal',
  '/matchklocka/ndi-utvisning.html':'ndi-utvisning',
  '/matchklocka/jumbotron-gammal.html':'jumbotron-gammal',
  '/matchklocka/jumbotron-forslag.html':'jumbotron-forslag'
};

function normPath(p){try{p=decodeURIComponent(p)}catch(e){}p=path.posix.normalize(String(p||'/').replace(/\\/g,'/'));if(p.length>1&&p.endsWith('/'))p=p.slice(0,-1);return p}
function hrefOf(s){return '/screens/'+s.id+(s.query?'?'+s.query:'')}
function byId(id){return SCREENS.find(s=>s.id===id&&!s.variant)}
function existsIn(serve,rel){if(!serve||!rel)return false;try{return fs.existsSync(path.join(serve,rel))}catch(e){return false}}

function missingRequired(s,serve){return !!(s.requireFile&&!existsIn(serve,s.requireFile))}

/* /screens/<namn> → fil att servera, ev. tvingad query (om den saknas), eller alias-omdirigering. */
function resolve(pathname,search){
  const p=normPath(pathname);
  if(p==='/screens')return {menu:true};
  const m=p.match(/^\/screens\/([a-z0-9-]+)$/);
  if(!m)return null;
  const id=m[1];
  if(ALIAS[id]){
    const a=ALIAS[id];
    const q=new URLSearchParams(String(search||'').replace(/^\?/,''));
    String(a.query||'').split('&').filter(Boolean).forEach(kv=>{const i=kv.indexOf('=');const k=i<0?kv:kv.slice(0,i),v=i<0?'':kv.slice(i+1);if(!q.has(k))q.set(k,v)});
    const qs=q.toString();
    return {redirect:'/screens/'+a.id+(qs?'?'+qs:'')}
  }
  const s=byId(id);
  if(!s)return null;
  let q=String(search||'');
  if(s.query){
    const params=new URLSearchParams(q.replace(/^\?/,''));
    let added=false;
    String(s.query).split('&').filter(Boolean).forEach(kv=>{const i=kv.indexOf('=');const k=i<0?kv:kv.slice(0,i),v=i<0?'':kv.slice(i+1);if(!params.has(k)){params.set(k,v);added=true}});
    if(added)return {redirect:'/screens/'+s.id+'?'+params.toString()};
  }
  return {file:s.file,id:s.id};
}

/* Gamla visningsadresser och /matchklocka-menyn → nya sökvägar. Behåller query. */
function redirectFrom(pathname,search){
  const p=normPath(pathname);
  if(p==='/start')return '/';
  if(p==='/matchklocka'||p==='/matchklocka/index.html')return '/';
  if(p==='/matchklocka/bas.html'){
    const q=new URLSearchParams(String(search||'').replace(/^\?/,''));
    const lag=String(q.get('lag')||'').toLowerCase()==='borta'?'borta':'hemma';
    q.set('lag',lag);
    return '/screens/bas-'+lag+'?'+q.toString();
  }
  const id=OLD_FILE[p];
  if(!id)return null;
  const q=String(search||'').replace(/^\?/,'' );
  return '/screens/'+id+(q?'?'+q:'');
}

function available(serve){
  return SCREENS.map(s=>{
    const miss=missingRequired(s,serve);
    const fileMissing=!s.requireFile&&!existsIn(serve,s.file.replace(/^\//,''));
    return Object.assign({},s,{missing:miss||fileMissing,placeholder:miss});
  });
}

function page(o){
  const P=o.port,ips=o.ips||[],hn=o.hostname||'',pin=!!o.pin,ver=o.version||'',serve=o.serve||'';
  const bases=ips.map(i=>'http://'+i+':'+P);
  if(hn)bases.push('http://'+hn+'.local:'+P);
  const main=bases[0]||('http://localhost:'+P);
  const rows=available(serve);
  let h='<!doctype html><html lang="sv"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Skärmar – Matchklocka-hubben</title>'+
  '<style>*{box-sizing:border-box}body{margin:0;background:#0b0b0b;color:#fff;font:16px/1.4 -apple-system,Segoe UI,Roboto,sans-serif}header{background:#AF2E32;padding:16px 22px}h1{margin:0;font-size:26px}header small{opacity:.85;display:block;margin-top:4px}'+
  'main{max-width:1000px;margin:0 auto;padding:18px}h2{color:#AF2E32;font-size:14px;letter-spacing:2px;text-transform:uppercase;margin:26px 0 8px}'+
  '.ok{display:inline-block;width:12px;height:12px;border-radius:50%;background:#2ecc71;margin-right:8px;vertical-align:middle}.bad{background:#e74c3c}'+
  '.cards{display:flex;flex-wrap:wrap;gap:16px}.card{background:#151515;border-left:6px solid #AF2E32;border-radius:10px;padding:16px 18px;display:flex;gap:18px;align-items:center;flex:1 1 420px}'+
  '.card .u{font:800 22px/1.2 ui-monospace,Menlo,Consolas,monospace;word-break:break-all}.card small{color:#bbb;display:block;margin-top:6px}.card svg{flex:none;border-radius:6px}'+
  'table{width:100%;border-collapse:collapse}td{padding:12px 8px;border-bottom:1px solid #222;vertical-align:middle}td.n{font-weight:700;font-size:17px}td small{color:#aaa;font-weight:400;display:block;margin-top:2px}'+
  '.addr{font:700 15px/1.3 ui-monospace,Menlo,Consolas,monospace;color:#fff;word-break:break-all;margin-top:6px}'+
  'a.b,button{background:#222;color:#fff;border:1px solid #444;border-radius:8px;padding:7px 12px;font:600 14px inherit;font-family:inherit;text-decoration:none;cursor:pointer;margin:0 6px 6px 0;display:inline-block}a.b:hover,button:hover{background:#333}'+
  '.wait{background:#333;color:#FFB000;border-radius:5px;padding:1px 6px;font-size:11px;font-weight:800;margin-left:6px}.qrbox{display:none;padding:10px 0}.qrbox.on{display:block}'+
  '.tips{background:#151515;border-radius:10px;padding:6px 20px;color:#ddd}.tips li{margin:8px 0}code{background:#222;padding:1px 6px;border-radius:4px}'+
  '.note{color:#bbb;font-size:14px;margin:0 0 12px}</style></head><body>'+
  '<header><h1><span class="ok" id="dot"></span>Skärmar</h1><small>Teknikermeny · Matchklocka-hubben · version '+esc(ver)+' · port '+P+' · <span id="cnt">…</span></small></header><main>';
  h+='<p class="note">Här listas visningsskärmarna med den adress enheten ska öppna. Menyn kräver samma PIN som operatörsmodulerna. Själva skärmsidorna är öppna utan PIN.</p>';
  if(!bases.length)h+='<h2>Inget nätverk hittades</h2><div class="tips"><p>Datorn verkar inte vara ansluten till något nätverk. Koppla in nätverkskabel / anslut till Wi-Fi/routern och starta hubben igen. Under tiden fungerar sidorna bara på den här datorn: <code>http://localhost:'+P+'/screens/</code></p></div>';
  else{
    h+='<h2>Hubbens adress på det här nätverket</h2><div class="cards">';
    bases.forEach((b,i)=>{const isName=/\.local:/.test(b);
      h+='<div class="card"><div>'+qrSvg(b+'/screens/',170).replace('<svg','<svg style="display:block"')+'</div><div><div class="u">'+esc(b)+'/screens/</div><small>'+(isName?'Datornamnet (Bonjour) – fungerar på Mac, iPad, iPhone och Windows 10+, inte alla Android. Skriv IP-adressen där.':(i===0?'Skriv in adressen eller skanna QR-koden med kameran.':'Annan nätverksadress (t.ex. kabel och Wi-Fi samtidigt) – använd den som enheten kan nå.'))+'</small></div></div>'});
    h+='</div>';
  }
  GROUPS.forEach(g=>{
    const list=rows.filter(s=>s.group===g.id);
    if(!list.length)return;
    h+='<h2>'+esc(g.title)+'</h2><table>';
    list.forEach((s,i)=>{
      const full=main+hrefOf(s),id='q-'+s.group+'-'+i;
      if(s.placeholder){
        h+='<tr><td class="n">'+esc(s.name)+'<span class="wait">Inte på plats än</span>'+(s.note?'<br><small>'+esc(s.note)+'</small>':'')+'<div class="addr">Planerad adress: '+esc(full)+'</div></td><td></td></tr>';
        return;
      }
      if(s.missing){
        h+='<tr><td class="n">'+esc(s.name)+'<span class="wait">Saknas</span>'+(s.note?'<br><small>'+esc(s.note)+'</small>':'')+'</td><td></td></tr>';
        return;
      }
      h+='<tr><td class="n">'+esc(s.name)+(s.note?'<br><small>'+esc(s.note)+'</small>':'')+'<div class="addr" data-addr="'+esc(full)+'">'+esc(full)+'</div><div class="qrbox" id="'+id+'">'+qrSvg(full,170)+'</div></td>'+
        '<td style="text-align:right;white-space:nowrap"><a class="b" href="'+esc(hrefOf(s))+'" target="_blank" rel="noopener">Öppna här</a><button type="button" data-c="'+esc(full)+'">Kopiera adress</button><button type="button" data-q="'+id+'">QR</button></td></tr>';
    });
    h+='</table>';
  });
  h+='<h2>Bra att veta</h2><div class="tips"><ul>'+
   '<li>Öppna alltid skärmarna <b>från hubben</b> (adresserna ovan) – inte från github.io. Då synkas de automatiskt, utan internet.</li>'+
   '<li>Gamla adresser (till exempel <code>/matchklocka/jumbotron.html</code>) omdirigeras hit, så redan inställda skärmar i arenan fortsätter fungera.</li>'+
   '<li>Alla enheter ska sitta på <b>samma nätverk</b> (inte gästnätverk med klientisolering). Första gången frågar macOS om inkommande anslutningar – svara <b>Tillåt</b>.</li>'+
   '<li>Visningsskärmarna (själva sidorna) är öppna utan PIN. '+(pin?'Den här menyn och operatörsmodulerna kräver PIN-kod första gången på varje enhet (samma kod, 30 dagar). Admin har egen PIN.':'Ingen PIN-kod är satt – alla på nätverket kan öppna den här menyn och styra operatörsmodulerna. Sätt <code>adminPin</code> i config.json för att låsa dem.')+'</li>'+
   '<li>Admin (status, enheter, logg) finns på <code>'+esc(main)+'/admin</code> och kräver PIN samt att enheten sitter på det lokala nätet.</li>'+
   '<li>Låt datorn vara på, med nätadapter, och lämna hubbens Terminal-fönster öppet under matchen. Du kan stänga den här fliken.</li>'+
   '<li>Ger datorn fast IP (DHCP-reservation i routern) blir adresserna likadana varje gång.</li></ul></div></main>'+
  '<script>document.addEventListener("click",function(e){var t=e.target;if(t.dataset.c){var v=t.dataset.c,done=function(){var o=t.textContent;t.textContent="Kopierad ✓";setTimeout(function(){t.textContent=o},1200)};'+
  'if(navigator.clipboard&&window.isSecureContext)navigator.clipboard.writeText(v).then(done,function(){prompt("Kopiera adressen:",v)});else{var a=document.createElement("textarea");a.value=v;document.body.appendChild(a);a.select();try{document.execCommand("copy");done()}catch(x){prompt("Kopiera adressen:",v)}a.remove()}}'+
  'if(t.dataset.q)document.getElementById(t.dataset.q).classList.toggle("on")});'+
  'function st(){fetch("/status",{cache:"no-store"}).then(function(r){return r.json()}).then(function(j){document.getElementById("dot").className="ok";document.getElementById("cnt").textContent=(j.lanEnheter||0)+" enheter synkade"+(j.klockor?" · "+j.klockor+" TV-klocka":"")}).catch(function(){document.getElementById("dot").className="ok bad";document.getElementById("cnt").textContent="ingen kontakt med hubben"})}st();setInterval(st,3000);</script></body></html>';
  return h;
}

module.exports={page,qrSvg,resolve,redirectFrom,hrefOf,SCREENS,ALIAS};
