@echo off
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js saknas. Installera LTS fran https://nodejs.org och starta om. & pause & exit /b 1)
:loop
node bridge.js %*
echo.
echo Bridgen stoppade. Startar om om 3 sekunder (stang fonstret for att avsluta)...
timeout /t 3 >nul
goto loop
