#!/bin/sh
# Linux / Raspberry Pi / macOS med Node installerat. (Mac utan Node: använd Starta-Hubben.command.)
cd "$(dirname "$0")" || exit 1
command -v node >/dev/null 2>&1 || { echo "Node.js saknas (installera Node 16 eller nyare) – eller använd Starta-Hubben.command på Mac."; exit 1; }
while true; do
  node bridge.js "$@"
  echo "Bridgen stoppade. Startar om om 3 sekunder (Ctrl+C för att avsluta)..."
  sleep 3
done
