#!/bin/sh
cd "$(dirname "$0")" || exit 1
command -v node >/dev/null 2>&1 || { echo "Node.js saknas (installera Node 16 eller nyare)."; exit 1; }
while true; do
  node bridge.js "$@"
  echo "Bridgen stoppade. Startar om om 3 sekunder (Ctrl+C för att avsluta)..."
  sleep 3
done
